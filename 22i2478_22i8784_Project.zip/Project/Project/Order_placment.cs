﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace database_project
{
    public partial class Order_placment : Form
    {


        string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        int Customer_id;


        public Order_placment()
        {
            InitializeComponent();
        }
        //form load function
        public Order_placment(int customer_id)
        {
            InitializeComponent();
            Customer_id = customer_id;
        }




        private void search_box_TextChanged(object sender, EventArgs e)
        {
            //set placeholder
            //searching insode the data grid view
            string search = search_box.Text;
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                if (dataGridView1.Rows[i].Cells[0].Value.ToString().Contains(search))
                {
                    dataGridView1.Rows[i].Visible = true;
                }
                else
                {
                    dataGridView1.Rows[i].Visible = false;
                }
            }


        }



        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            //call the grid view function to display the data



        }
        private void grid_view()
        {
            //apply query to get the data from the database
            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand("select * from items", con);
            dr = cmd.ExecuteReader();
            //just write the selected coluns like name price and Quantity
            while (dr.Read())
            {
                dataGridView1.Rows.Add(dr["item_name"], dr["price"], dr["Quantity"]);
            }
            con.Close();


        }



        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (string.IsNullOrEmpty(selected_quantity.Text))
            {
                MessageBox.Show("Please select the quantity");
                return;
            }
            if (Convert.ToInt32(selected_quantity.Text) <= 0)
            {
                MessageBox.Show("Please select the quantity");
                return;
            }
            // check that the selected quantity is not greater than the grid[2]
            if (Convert.ToInt32(selected_quantity.Text) > Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[2].Value))
            {
                MessageBox.Show("The quantity is greater than the available quantity");
                return;
            }


            name_label.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            price_label.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            total_label.Text = (Convert.ToDouble(price_label.Text) * Convert.ToInt32(selected_quantity.Text)).ToString();
        }

        private void Order_placment_Load(object sender, EventArgs e)
        {
            grid_view();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            //if the grid view is empty then show the message box u cannt place the order without selecting the item
            //check if the grid view is empty code 2nd row is empty

            if (Orders.Rows.Count > 1)
            {
                try
                {
                    using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        con.Open();

                        // Insert the order
                        using (SqlCommand insertOrderCmd = new SqlCommand("INSERT INTO Orders (Customer_ID, Order_date) VALUES (@customer_id, GETDATE()); SELECT SCOPE_IDENTITY();", con))
                        {
                            insertOrderCmd.Parameters.AddWithValue("@customer_id", Customer_id);
                            int orderId = Convert.ToInt32(insertOrderCmd.ExecuteScalar());

                            // Insert the order items
                            foreach (DataGridViewRow row in Orders.Rows)
                            {
                                if (row.Cells[0].Value != null && row.Cells[1].Value != null && row.Cells[2].Value != null && row.Cells[3].Value != null)
                                {
                                    string itemName = row.Cells[0].Value.ToString();
                                    string price = row.Cells[1].Value.ToString();
                                    int quantity = Convert.ToInt32(row.Cells[2].Value);
                                    string totalPrice = row.Cells[3].Value.ToString();

                                    using (SqlCommand getItemIdCmd = new SqlCommand("SELECT Item_id FROM Items WHERE item_name = @item_name", con))
                                    {
                                        getItemIdCmd.Parameters.AddWithValue("@item_name", itemName);
                                        object itemId = getItemIdCmd.ExecuteScalar();
                                        int itemIdValue = itemId != null ? Convert.ToInt32(itemId) : -1;

                                        if (itemIdValue > 0)
                                        {
                                            using (SqlCommand insertOrderItemCmd = new SqlCommand("INSERT INTO Order_Items (Item_ID, Order_ID, Quantity) VALUES (@item_id, @order_id, @quantity)", con))
                                            {
                                                insertOrderItemCmd.Parameters.AddWithValue("@item_id", itemIdValue);
                                                insertOrderItemCmd.Parameters.AddWithValue("@order_id", orderId);
                                                insertOrderItemCmd.Parameters.AddWithValue("@quantity", quantity);
                                                insertOrderItemCmd.ExecuteNonQuery();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    MessageBox.Show("Order placed successfully");
                    Orders.Rows.Clear();
                    Grand_Total_label.Text = "0.0";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please add items to the cart before placing an order");
            }



        }

        private void Add_to_cart_Click(object sender, EventArgs e)
        {

            double grand_total = 0.0;
            // Check if the labels are not empty, especially the name label and price label
            if (string.IsNullOrEmpty(name_label.Text) || string.IsNullOrEmpty(price_label.Text))
            {
                MessageBox.Show("Please select the item");
                return;
            }

            // Check if the selected quantity is not empty and is a valid number
            if (!int.TryParse(selected_quantity.Text, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Please enter a valid quantity");
                return;
            }

            string item_name = name_label.Text;
            string price = price_label.Text;
            string total_price = total_label.Text; // Calculate total price

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    // Check if the customer already has a cart
                    using (SqlCommand cmd = new SqlCommand("SELECT Cart_ID FROM Cart WHERE Customer_ID = @customer_id", con))
                    {
                        cmd.Parameters.AddWithValue("@customer_id", Customer_id);
                        object cartId = cmd.ExecuteScalar();
                        int cartIdValue = cartId != null ? Convert.ToInt32(cartId) : -1;

                        // If customer has a cart
                        if (cartIdValue > 0)
                        {
                            // Get the item ID
                            using (SqlCommand getItemIdCmd = new SqlCommand("SELECT Item_id FROM Items WHERE item_name = @item_name", con))
                            {
                                getItemIdCmd.Parameters.AddWithValue("@item_name", item_name);
                                object itemId = getItemIdCmd.ExecuteScalar();
                                int itemIdValue = itemId != null ? Convert.ToInt32(itemId) : -1;

                                // If the item exists
                                if (itemIdValue > 0)
                                {
                                    // Insert item into Cart_Items
                                    using (SqlCommand insertCmd = new SqlCommand("INSERT INTO Cart_Items (Cart_ID, item_Id, Quantity) VALUES (@cart_id, @item_id, @quantity)", con))
                                    {
                                        insertCmd.Parameters.AddWithValue("@cart_id", cartIdValue);
                                        insertCmd.Parameters.AddWithValue("@item_id", itemIdValue);
                                        insertCmd.Parameters.AddWithValue("@quantity", quantity);
                                        insertCmd.ExecuteNonQuery();
                                    }
                                }
                            }
                        }
                        else
                        {
                            // Create a new cart for the customer
                            using (SqlCommand createCartCmd = new SqlCommand("INSERT INTO Cart (Customer_ID, creation_date) VALUES (@customer_id, GETDATE()); SELECT SCOPE_IDENTITY();", con))
                            {
                                createCartCmd.Parameters.AddWithValue("@customer_id", Customer_id);
                                cartIdValue = Convert.ToInt32(createCartCmd.ExecuteScalar());
                            }
                        }
                    }
                }
                //grand_total=total_price +grand_total_label.Text;
                grand_total = Convert.ToDouble(total_price) + Convert.ToDouble(Grand_Total_label.Text);



                // Update UI or perform additional actions
                Orders.Rows.Add(item_name, price, quantity, total_price);
                Grand_Total_label.Text = grand_total.ToString();

                selected_quantity.Text = "";
                total_label.Text = "";
                price_label.Text = "";
                name_label.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void Total_Click(object sender, EventArgs e)
        {
        }

        private void label10_Click(object sender, EventArgs e)
        {
            //exit application
            Application.Exit();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand("select F_name, L_name from Customer where Customer_ID = " + Customer_id, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            string name = dr["F_name"].ToString() + " " + dr["L_name"].ToString();
            customer_dashboard f = new customer_dashboard(Customer_id, name);
            f.Show();
            this.Hide();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Emp_details_view : Form
    {
        public Emp_details_view()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //move back to admin form
            Admin_Form admin_Form = new Admin_Form();
            admin_Form.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from Employee", con);
                
                SqlDataReader reader = cmd.ExecuteReader();

                //add data to the table
                tableLayoutPanel1.Controls.Add(new Label() { Text = "Employee ID" });
                tableLayoutPanel1.Controls.Add (new Label() { Text ="Account ID"});
                tableLayoutPanel1.Controls.Add(new Label() { Text = "Employee First Name" });
                tableLayoutPanel1.Controls.Add(new Label() { Text = "Employee Last Name" });
                tableLayoutPanel1.Controls.Add(new Label() { Text = "Gender"});
                tableLayoutPanel1.Controls.Add(new Label() { Text = "Phone Number" });
                tableLayoutPanel1.Controls.Add(new Label() { Text = "Email" });
                tableLayoutPanel1.Controls.Add(new Label() { Text = "Salary" });

                while (reader.Read())
                {
                    //add items to the table
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["Employee_ID"].ToString() });
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["Account_ID"].ToString() });
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["F_Name"].ToString() });
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["L_Name"].ToString() });
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["Gender"].ToString() });
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["PhoneNumber"].ToString() });
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["Email"].ToString() });
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["Salary"].ToString() });
                    
                }

            }
        }

        private void Count_btn_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select count(*) from Employee", con);
                SqlDataReader reader = cmd.ExecuteReader();
                
                //show in a message box
                while (reader.Read())
                {
                    MessageBox.Show("Number of Employees: " + reader[0].ToString());
                }

            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                
                SqlCommand cmd = new SqlCommand("Select U.UserName, E.F_name, E.L_name from User_Account U Join Employee E ON U.Account_id=E.Account_ID where E.Salary>(Select avg(Convert(Decimal(10,2),E1.Salary)) from Employee E1)", con);
                SqlDataReader reader = cmd.ExecuteReader();

                //add headers to the table
                tableLayoutPanel1.Controls.Add(new Label() { Text = "User Name" });
                tableLayoutPanel1.Controls.Add(new Label() { Text = "First Name" });
                tableLayoutPanel1.Controls.Add(new Label() { Text = "Last Name" });

                while (reader.Read())
                {
                   
                   

                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["UserName"].ToString() });
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["F_Name"].ToString() });
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["L_Name"].ToString() });


                }

            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Add_Items_Form : Form
    {

        //connect to sql
        
        


        public Add_Items_Form()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            //move to Admin_Form
            Admin_Form admin_Form = new Admin_Form();
            admin_Form.Show();
            this.Hide();

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            


        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void add_item_btn_Click(object sender, EventArgs e)
        {
            if (item_name_tbox.Text == null || Price_tbox.Text == null || Quantity_tbox.Text == null || (tea_rbtn.Checked==false && Cake_rbtn.Checked==false && Coffee_rbtn.Checked==false && shake_rbtn.Checked==false))
            {
                MessageBox.Show("Please fill all fields");
            }
            else
            {
                String item_name = item_name_tbox.Text;
                int price = Convert.ToInt32(Price_tbox.Text);
                int quantity = Convert.ToInt32(Quantity_tbox.Text);
                int category = 0;
                if (tea_rbtn.Checked == true)
                {
                    category = 1;
                }
                else if (Cake_rbtn.Checked == true)
                {
                    category = 2;
                }
                else if (Coffee_rbtn.Checked == true)
                {
                    category = 3;
                }
                else if (shake_rbtn.Checked == true)
                {
                    category = 4;
                }

                string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
               


                try { 

                    //add item to database
                    using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("INSERT INTO Items VALUES (@item_Name, @price, @quantity, @Category_id)", con);
                        cmd.Parameters.AddWithValue("@item_name", item_name);
                        cmd.Parameters.AddWithValue("@price", price);
                        cmd.Parameters.AddWithValue("@quantity", quantity);
                        cmd.Parameters.AddWithValue("@Category_id", category);
                        cmd.ExecuteNonQuery();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }


                MessageBox.Show("Item Added");
            }
        }

        private void Add_Items_Form_Load(object sender, EventArgs e)
        {
            
        }

        private void Add_ing_btn_Click(object sender, EventArgs e)
        {
            //move to Add_Ingredients_Form
            Add_Ingedients add_Ingredients_Form = new Add_Ingedients();
            add_Ingredients_Form.Show();
            this.Hide();

        }
    }
}

﻿using Project;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class customer_dashboard : Form
    {
        //constructor that has the customer id and has the customer name
         string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        int id;

        public customer_dashboard(int customer_id, string s)
        {
            InitializeComponent();
            label4.Text = s;
            label3.Text = customer_id.ToString();
        }
        //id constructor
        public customer_dashboard(int id)
        {
            InitializeComponent();
            label3.Text = id.ToString();
            //select F_name, L_name from Customer where Customer_ID = id
            //assign the name to the label
            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand("select F_name, L_name from Customer where Customer_ID = " + id, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            label4.Text = dr["F_name"].ToString() + " " + dr["L_name"].ToString();
            dr.Close();
        }


        public customer_dashboard()
        {
            InitializeComponent();
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }



        private void button1_Click(object sender, EventArgs e)
        {
            //send the customer id to the reserve table form
            reserve_table f = new reserve_table(Convert.ToInt32(label3.Text));


            f.Show();
            this.Hide();


        }

        private void Place_order_btn_Click(object sender, EventArgs e)
        {
            Order_placment f = new Order_placment(Convert.ToInt32(label3.Text));
            f.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //send the customer id to the view order form
            Feedback f = new Feedback(Convert.ToInt32(label3.Text));
            f.Show();
            this.Hide();


        }

        private void button5_Click(object sender, EventArgs e)
        {
            
            CustomerDetails f = new CustomerDetails(Convert.ToInt32(label3.Text));
            f.Show();
            this.Hide();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }


        private void button3_Click_1(object sender, EventArgs e)
        {
            View_previous_orders f = new View_previous_orders(Convert.ToInt32(label3.Text));
            f.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            //exit the application
            Application.Exit();
                
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Project;

namespace database_project
{
    public partial class Form4 : Form
    {





        string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        int Customer_id;
        public Form4()
        {
            InitializeComponent();



        }

        private void login_user_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void Customer_btn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Admin_btn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Seller_btn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void pass_login_TextChanged(object sender, EventArgs e)
        {

        }



        private void login_btn_Click(object sender, EventArgs e)
        {

            
                string username = login_user_name.Text;
                string password = pass_login.Text;

                if (username == "" || password == "" || (Customer_btn.Checked == false && Seller_btn.Checked == false && Admin_btn.Checked == false))
                {
                    MessageBox.Show("Please enter both username and password");
                }
                else
                {
                    con = new SqlConnection(connectionString);
                    con.Open();//
                               //select* from User_Account u where u.UserName = 'xyz' AND u.UserPassword = 'xyz'
                    string query = "select u.Account_id from User_Account u where u.UserName = '" + username + "' AND u.UserPassword = '" + password + "'";
                    cmd = new SqlCommand(query, con);
                    dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        //check button 
                        if (Customer_btn.Checked)
                        {
                            try
                            {
                                //select c.Customer_ID,c.F_name from Customer c join User_Account u on c.Account_ID = u.Account_id
                                string query1 = "select c.Customer_ID,c.F_name,c.L_name from Customer c join User_Account u on c.Account_ID =" + dr["Account_id"];
                                cmd = new SqlCommand(query1, con);
                                dr.Close();
                                dr = cmd.ExecuteReader();

                                if (dr.Read())
                                {
                                    Customer_id = Convert.ToInt32(dr["Customer_ID"]);
                                    customer_dashboard f = new customer_dashboard(Customer_id, dr["F_name"].ToString() + " " + dr["L_name"].ToString());
                                    f.Show();
                                    this.Hide();

                                }
                                else
                                {
                                    MessageBox.Show("invalid user name or password !");

                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }

                        }
                        
                        else if (Admin_btn.Checked)
                        {
                            try
                            {
                                //select a.Admin_ID,a.F_name from Admin a join User_Account u on a.Account_ID = u.Account_id
                                string query1 = "select a.Administrator_ID from Administrator a join User_Account u on a.Account_ID =" + dr["Account_id"];
                                cmd = new SqlCommand(query1, con);
                                dr.Close();
                                dr = cmd.ExecuteReader();


                                if (dr.Read())
                                {
                                    Admin_Form f = new Admin_Form(Convert.ToInt32(dr["Administrator_ID"]));
                                    f.Show();
                                    this.Hide();

                                }
                                else
                                {
                                    MessageBox.Show("invalid user name or password !");

                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }
                        }
                        else if (Seller_btn.Checked)
                        {
                            try
                            {
                                
                                string query1 = "select e.Employee_ID From Employee e join User_Account u on e.Account_ID =" + dr["Account_id"];
                                cmd = new SqlCommand(query1, con);
                                dr.Close();
                                dr = cmd.ExecuteReader();

                                if (dr.Read())
                                {
                                    Seller_dashboard f = new Seller_dashboard(Convert.ToInt32(dr["Employee_ID"]));
                                    f.Show();
                                    this.Hide();

                                }
                                else
                                {
                                    MessageBox.Show("invalid user name or password !");

                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }
                        }

                    }
                    else
                    {
                        MessageBox.Show("Invalid Username or Password");
                    }


                }


            }


        

        private void Login_register_Click(object sender, EventArgs e)
        {
            Form3 s = new Form3();
            s.Show();
            this.Hide();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
    }
}

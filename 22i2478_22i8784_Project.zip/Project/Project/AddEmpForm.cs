﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class AddEmpForm : Form
    {
        public AddEmpForm()
        {
            InitializeComponent();
        }

        private void AddEmpForm_Load(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

     

        private void Add_emp_btn_Click_1(object sender, EventArgs e)
        {
            //check all fields are filled then display message box
            if (f_name_tbox.Text == null || L_name_tbox.Text == null || pnum_tbox.Text == null || email_tbox.Text == null || (male_rbtn.Checked == false && female_rbtn.Checked == false))
            {
                
                

                MessageBox.Show("Please fill all fields");
            }
            else
            {
                string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();

                try
                {
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO User_Account VALUES (@UserName, @UserPassword)", con))
                    {
                        cmd.Parameters.AddWithValue("@UserName", User_name_tbox.Text);
                        cmd.Parameters.AddWithValue("@UserPassword", password_tbox.Text);
                        cmd.ExecuteNonQuery();
                    } 
                  
                    //get the account id of the user
                    int account_id = 0;
                    using (SqlCommand cmd2 = new SqlCommand("SELECT Account_id FROM User_Account WHERE UserName = @UserName AND UserPassword = @UserPassword", con))
                    {
                        cmd2.Parameters.AddWithValue("@UserName", User_name_tbox.Text);
                        cmd2.Parameters.AddWithValue("@UserPassword", password_tbox.Text);
                        account_id = (int)cmd2.ExecuteScalar();
                    }

                  

                    //MessageBox.Show(account_id);
                    
                    string gender = "";

                    if (male_rbtn.Checked == true)
                    {
                        gender = "Male";
                    }
                    else
                    {
                        gender = "Female";
                    }

                    

                    //add employee to database
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO Employee VALUES (@Account_ID, @F_Name, @L_Name, @Gender, @PhoneNumber, @Email, @salary)", con))
                    {
                        cmd.Parameters.AddWithValue("@Account_ID", account_id);
                        cmd.Parameters.AddWithValue("@F_Name", f_name_tbox.Text);
                        cmd.Parameters.AddWithValue("@L_Name", L_name_tbox.Text);
                        cmd.Parameters.AddWithValue("@Gender", gender);
                        cmd.Parameters.AddWithValue("@PhoneNumber", pnum_tbox.Text);
                        cmd.Parameters.AddWithValue("@Email", email_tbox.Text);
                        cmd.Parameters.AddWithValue("@salary", Salary_Picker.Value).ToString();
                        cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                MessageBox.Show("Employee added successfully");
                //add employee to database
            }
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            Admin_Form form1 = new Admin_Form();
            form1.Show();
            this.Hide();
        }

        private void pnum_tbox_TextChanged(object sender, EventArgs e)
        {
            if (pnum_tbox.Text.All(char.IsDigit) && pnum_tbox.Text.Length == 11)
            {
                pnum_tbox.BackColor = Color.LightGreen;
            }
            else
            {
                pnum_tbox.BackColor = Color.Red;
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void password_tbox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

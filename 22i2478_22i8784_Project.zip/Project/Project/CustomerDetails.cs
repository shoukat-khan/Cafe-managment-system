﻿using database_project;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{

    public partial class CustomerDetails : Form
    {
        int id;

         string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;



        public CustomerDetails(int id)
        {
            InitializeComponent();
            this.id = id;
        }

        private void Add_emp_btn_Click(object sender, EventArgs e)
        {

        }

        private void CustomerDetails_Load(object sender, EventArgs e)
        {

            //read the customer details from the database and display it in the form
            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand("select * from Customer where Customer_ID = " + id, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            
            f_name_tbox.Text = dr["F_name"].ToString();
            L_name_tbox.Text = dr["L_name"].ToString();
            pnum_tbox.Text = dr["PhoneNumber"].ToString();
            email_tbox.Text = dr["Email"].ToString();


            dr.Close();
           


        }

        private void Back_btn_Click(object sender, EventArgs e)
        {

            customer_dashboard f = new customer_dashboard(id, f_name_tbox.Text + " " + L_name_tbox.Text);
            f.Show();
            this.Hide();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
   

    public partial class EditEmpDetails : Form
    {
        int sellerId;
        string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;

        public EditEmpDetails(int seller_id)
        {
            InitializeComponent();
            this.sellerId = seller_id;
        }

        private void EditEmpDetails_Load(object sender, EventArgs e)
        {

            try { 
                con = new SqlConnection(connectionString);
                con.Open();
                cmd = new SqlCommand("select * from Employee where Employee_ID = @seller_id", con);
                cmd.Parameters.AddWithValue("@seller_id", sellerId);
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    f_name_tbox.Text = dr["F_name"].ToString();
                    L_name_tbox.Text = dr["L_name"].ToString();
                    email_tbox.Text = dr["Email"].ToString();
                    pnum_tbox.Text = dr["PhoneNumber"].ToString();
                    Salary_Picker.Value = Convert.ToDecimal(dr["Salary"]);

                    string gender;

                    string query = "select Gender from Employee where Employee_ID = @seller_id";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@seller_id", sellerId);
                    dr.Close();
                    gender = cmd.ExecuteScalar().ToString();

                    if (gender == "Male")
                    {
                        male_rbtn.Checked = true;
                    }

                    else
                    {
                        female_rbtn.Checked = true;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            //move to Seller_Profile
            Seller_Profile seller_Profile = new Seller_Profile(sellerId);
            seller_Profile.Show();
            this.Hide();
        }

        private void Add_emp_btn_Click(object sender, EventArgs e)
        {

            try
            {
                
                con = new SqlConnection(connectionString);
                con.Open();
                cmd = new SqlCommand("update Employee set F_name = @f_name, L_name = @l_name, Email = @email, PhoneNumber = @pnum, Salary = @sal where Employee_ID = @seller_id", con);
                cmd.Parameters.AddWithValue("@f_name", f_name_tbox.Text);
                cmd.Parameters.AddWithValue("@l_name", L_name_tbox.Text);
                cmd.Parameters.AddWithValue("@email", email_tbox.Text);
                cmd.Parameters.AddWithValue("@pnum", pnum_tbox.Text);
                cmd.Parameters.AddWithValue("@sal", Salary_Picker.Value);
                cmd.Parameters.AddWithValue("@seller_id", sellerId);
                cmd.ExecuteNonQuery();

                MessageBox.Show("Employee details updated successfully");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void email_tbox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

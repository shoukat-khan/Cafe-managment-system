﻿namespace database_project
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.panel1 = new System.Windows.Forms.Panel();
            this.signup_to_login_here = new System.Windows.Forms.Label();
            this.PASS_TEXT = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Phone_no = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Last_name = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.FIrst_name = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.signup_btn = new System.Windows.Forms.Button();
            this.signup_username = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Gen = new System.Windows.Forms.Label();
            this.Gender = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.signup_email = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.signup_to_login_here);
            this.panel1.Controls.Add(this.PASS_TEXT);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.Phone_no);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.Last_name);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.FIrst_name);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.signup_btn);
            this.panel1.Controls.Add(this.signup_username);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(-2, -2);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(625, 370);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // signup_to_login_here
            // 
            this.signup_to_login_here.AutoSize = true;
            this.signup_to_login_here.Cursor = System.Windows.Forms.Cursors.Hand;
            this.signup_to_login_here.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signup_to_login_here.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.signup_to_login_here.Location = new System.Drawing.Point(522, 335);
            this.signup_to_login_here.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.signup_to_login_here.Name = "signup_to_login_here";
            this.signup_to_login_here.Size = new System.Drawing.Size(91, 17);
            this.signup_to_login_here.TabIndex = 9;
            this.signup_to_login_here.Text = "Login here ";
            this.signup_to_login_here.Click += new System.EventHandler(this.signup_to_login_here_Click);
            // 
            // PASS_TEXT
            // 
            this.PASS_TEXT.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PASS_TEXT.Location = new System.Drawing.Point(268, 153);
            this.PASS_TEXT.Margin = new System.Windows.Forms.Padding(2);
            this.PASS_TEXT.Multiline = true;
            this.PASS_TEXT.Name = "PASS_TEXT";
            this.PASS_TEXT.PasswordChar = '*';
            this.PASS_TEXT.Size = new System.Drawing.Size(134, 30);
            this.PASS_TEXT.TabIndex = 24;
            this.PASS_TEXT.TextChanged += new System.EventHandler(this.PASS_TEXT_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(446, 199);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 19);
            this.label9.TabIndex = 21;
            this.label9.Text = "Ph: no";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // Phone_no
            // 
            this.Phone_no.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Phone_no.Location = new System.Drawing.Point(446, 219);
            this.Phone_no.Margin = new System.Windows.Forms.Padding(2);
            this.Phone_no.Multiline = true;
            this.Phone_no.Name = "Phone_no";
            this.Phone_no.Size = new System.Drawing.Size(140, 30);
            this.Phone_no.TabIndex = 20;
            this.Phone_no.TextChanged += new System.EventHandler(this.Phone_no_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(446, 133);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 19);
            this.label8.TabIndex = 19;
            this.label8.Text = "Last_name";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // Last_name
            // 
            this.Last_name.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Last_name.Location = new System.Drawing.Point(446, 153);
            this.Last_name.Margin = new System.Windows.Forms.Padding(2);
            this.Last_name.Multiline = true;
            this.Last_name.Name = "Last_name";
            this.Last_name.Size = new System.Drawing.Size(140, 30);
            this.Last_name.TabIndex = 18;
            this.Last_name.TextChanged += new System.EventHandler(this.Last_name_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(446, 69);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 19);
            this.label7.TabIndex = 17;
            this.label7.Text = "First_name";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // FIrst_name
            // 
            this.FIrst_name.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FIrst_name.Location = new System.Drawing.Point(446, 89);
            this.FIrst_name.Margin = new System.Windows.Forms.Padding(2);
            this.FIrst_name.Multiline = true;
            this.FIrst_name.Name = "FIrst_name";
            this.FIrst_name.Size = new System.Drawing.Size(140, 30);
            this.FIrst_name.TabIndex = 16;
            this.FIrst_name.TextChanged += new System.EventHandler(this.FIrst_name_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(376, 335);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(149, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Already have account ";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // signup_btn
            // 
            this.signup_btn.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signup_btn.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.signup_btn.Location = new System.Drawing.Point(461, 288);
            this.signup_btn.Margin = new System.Windows.Forms.Padding(2);
            this.signup_btn.Name = "signup_btn";
            this.signup_btn.Size = new System.Drawing.Size(102, 35);
            this.signup_btn.TabIndex = 6;
            this.signup_btn.Text = "Sign up";
            this.signup_btn.UseVisualStyleBackColor = true;
            this.signup_btn.Click += new System.EventHandler(this.signup_btn_Click);
            // 
            // signup_username
            // 
            this.signup_username.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signup_username.Location = new System.Drawing.Point(265, 89);
            this.signup_username.Margin = new System.Windows.Forms.Padding(2);
            this.signup_username.Multiline = true;
            this.signup_username.Name = "signup_username";
            this.signup_username.Size = new System.Drawing.Size(137, 30);
            this.signup_username.TabIndex = 5;
            this.signup_username.TextChanged += new System.EventHandler(this.signup_username_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(265, 133);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 19);
            this.label3.TabIndex = 4;
            this.label3.Text = "Password";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(264, 69);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "User_name";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("HP Simplified", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(301, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(312, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Register your account";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(3, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(249, 370);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(10, 69);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(232, 221);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Gen
            // 
            this.Gen.AutoSize = true;
            this.Gen.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Gen.Location = new System.Drawing.Point(627, 67);
            this.Gen.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Gen.Name = "Gen";
            this.Gen.Size = new System.Drawing.Size(56, 19);
            this.Gen.TabIndex = 23;
            this.Gen.Text = "Gender";
            this.Gen.Click += new System.EventHandler(this.Gen_Click);
            // 
            // Gender
            // 
            this.Gender.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Gender.Location = new System.Drawing.Point(627, 87);
            this.Gender.Margin = new System.Windows.Forms.Padding(2);
            this.Gender.Multiline = true;
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(140, 30);
            this.Gender.TabIndex = 22;
            this.Gender.TextChanged += new System.EventHandler(this.Gender_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(624, 128);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 19);
            this.label6.TabIndex = 10;
            this.label6.Text = "Email";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // signup_email
            // 
            this.signup_email.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signup_email.Location = new System.Drawing.Point(627, 151);
            this.signup_email.Margin = new System.Windows.Forms.Padding(2);
            this.signup_email.Multiline = true;
            this.signup_email.Name = "signup_email";
            this.signup_email.Size = new System.Drawing.Size(140, 30);
            this.signup_email.TabIndex = 3;
            this.signup_email.TextChanged += new System.EventHandler(this.signup_email_TextChanged);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(799, 369);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Gen);
            this.Controls.Add(this.signup_email);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.label6);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label signup_to_login_here;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button signup_btn;
        private System.Windows.Forms.TextBox signup_username;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox signup_email;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Last_name;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox FIrst_name;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Phone_no;
        private System.Windows.Forms.Label Gen;
        private System.Windows.Forms.TextBox Gender;
        private System.Windows.Forms.TextBox PASS_TEXT;
    }
}
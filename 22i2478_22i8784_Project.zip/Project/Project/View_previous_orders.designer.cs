﻿namespace database_project
{
    partial class View_previous_orders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.Customer_name_label = new System.Windows.Forms.Label();
            this.last_month_order_btn = new System.Windows.Forms.RadioButton();
            this.Last_week_order_btn = new System.Windows.Forms.RadioButton();
            this.label11 = new System.Windows.Forms.Label();
            this.last_day_order_btn = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Customer_name_label);
            this.panel1.Controls.Add(this.last_month_order_btn);
            this.panel1.Controls.Add(this.Last_week_order_btn);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.last_day_order_btn);
            this.panel1.Controls.Add(this.label1);
            this.panel1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(195, 365);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Customer_name_label
            // 
            this.Customer_name_label.AutoSize = true;
            this.Customer_name_label.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Customer_name_label.Location = new System.Drawing.Point(21, 106);
            this.Customer_name_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Customer_name_label.Name = "Customer_name_label";
            this.Customer_name_label.Size = new System.Drawing.Size(0, 23);
            this.Customer_name_label.TabIndex = 43;
            // 
            // last_month_order_btn
            // 
            this.last_month_order_btn.AutoSize = true;
            this.last_month_order_btn.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.last_month_order_btn.Location = new System.Drawing.Point(9, 253);
            this.last_month_order_btn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.last_month_order_btn.Name = "last_month_order_btn";
            this.last_month_order_btn.Size = new System.Drawing.Size(177, 27);
            this.last_month_order_btn.TabIndex = 4;
            this.last_month_order_btn.TabStop = true;
            this.last_month_order_btn.Text = "Last_month_order";
            this.last_month_order_btn.UseVisualStyleBackColor = true;
            this.last_month_order_btn.CheckedChanged += new System.EventHandler(this.last_month_order_btn_CheckedChanged);
            // 
            // Last_week_order_btn
            // 
            this.Last_week_order_btn.AutoSize = true;
            this.Last_week_order_btn.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Last_week_order_btn.Location = new System.Drawing.Point(9, 219);
            this.Last_week_order_btn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Last_week_order_btn.Name = "Last_week_order_btn";
            this.Last_week_order_btn.Size = new System.Drawing.Size(172, 27);
            this.Last_week_order_btn.TabIndex = 3;
            this.Last_week_order_btn.TabStop = true;
            this.Last_week_order_btn.Text = "Last_week_orders";
            this.Last_week_order_btn.UseVisualStyleBackColor = true;
            this.Last_week_order_btn.CheckedChanged += new System.EventHandler(this.Last_week_order_btn_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(2, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 39);
            this.label11.TabIndex = 42;
            this.label11.Text = "⬅\r\n";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // last_day_order_btn
            // 
            this.last_day_order_btn.AutoSize = true;
            this.last_day_order_btn.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.last_day_order_btn.Location = new System.Drawing.Point(9, 183);
            this.last_day_order_btn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.last_day_order_btn.Name = "last_day_order_btn";
            this.last_day_order_btn.Size = new System.Drawing.Size(169, 27);
            this.last_day_order_btn.TabIndex = 2;
            this.last_day_order_btn.TabStop = true;
            this.last_day_order_btn.Text = "Last_Order_detail";
            this.last_day_order_btn.UseVisualStyleBackColor = true;
            this.last_day_order_btn.CheckedChanged += new System.EventHandler(this.last_day_order_btn_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("HP Simplified", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 76);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("HP Simplified", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label2.Location = new System.Drawing.Point(410, 22);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(199, 37);
            this.label2.TabIndex = 2;
            this.label2.Text = "Order History";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(682, 2);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 37);
            this.label10.TabIndex = 43;
            this.label10.Text = "❎";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(197, 84);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(505, 366);
            this.dataGridView1.TabIndex = 44;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.Control;
            this.label6.Font = new System.Drawing.Font("HP Simplified", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label6.Location = new System.Drawing.Point(264, 22);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 37);
            this.label6.TabIndex = 55;
            this.label6.Text = "H.S CAFE ";
            // 
            // View_previous_orders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 455);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "View_previous_orders";
            this.Text = "View_previous_orders";
            this.Load += new System.EventHandler(this.View_previous_orders_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton last_month_order_btn;
        private System.Windows.Forms.RadioButton Last_week_order_btn;
        private System.Windows.Forms.RadioButton last_day_order_btn;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label Customer_name_label;
    }
}
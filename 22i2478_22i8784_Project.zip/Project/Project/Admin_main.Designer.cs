﻿namespace Project
{
    partial class Admin_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin_Form));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Username_Label = new System.Windows.Forms.Label();
            this.Add_emp_btn = new System.Windows.Forms.Button();
            this.edit_admin_details_btn = new System.Windows.Forms.Button();
            this.Add_stk_btn = new System.Windows.Forms.Button();
            this.Remove_stk_btn = new System.Windows.Forms.Button();
            this.Options = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Edit_emp_btn = new System.Windows.Forms.Button();
            this.View_stk_btn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("HP Simplified", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(347, 43);
            this.label1.TabIndex = 0;
            this.label1.Text = "Administrator Portal";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("HP Simplified", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label2.Location = new System.Drawing.Point(582, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Logged in as: ";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Username_Label
            // 
            this.Username_Label.AutoSize = true;
            this.Username_Label.Font = new System.Drawing.Font("HP Simplified", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Username_Label.Location = new System.Drawing.Point(692, 32);
            this.Username_Label.Name = "Username_Label";
            this.Username_Label.Size = new System.Drawing.Size(0, 25);
            this.Username_Label.TabIndex = 2;
            this.Username_Label.Click += new System.EventHandler(this.label3_Click);
            // 
            // Add_emp_btn
            // 
            this.Add_emp_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add_emp_btn.Font = new System.Drawing.Font("HP Simplified", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_emp_btn.Location = new System.Drawing.Point(561, 180);
            this.Add_emp_btn.Name = "Add_emp_btn";
            this.Add_emp_btn.Size = new System.Drawing.Size(215, 35);
            this.Add_emp_btn.TabIndex = 3;
            this.Add_emp_btn.Text = "Add New Employee";
            this.Add_emp_btn.UseVisualStyleBackColor = true;
            this.Add_emp_btn.Click += new System.EventHandler(this.Add_emp_btn_Click);
            // 
            // edit_admin_details_btn
            // 
            this.edit_admin_details_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit_admin_details_btn.Font = new System.Drawing.Font("HP Simplified", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edit_admin_details_btn.Location = new System.Drawing.Point(50, 180);
            this.edit_admin_details_btn.Name = "edit_admin_details_btn";
            this.edit_admin_details_btn.Size = new System.Drawing.Size(173, 35);
            this.edit_admin_details_btn.TabIndex = 4;
            this.edit_admin_details_btn.Text = "Edit your Details";
            this.edit_admin_details_btn.UseVisualStyleBackColor = true;
            this.edit_admin_details_btn.Click += new System.EventHandler(this.edit_admin_details_btn_Click);
            // 
            // Add_stk_btn
            // 
            this.Add_stk_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add_stk_btn.Font = new System.Drawing.Font("HP Simplified", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_stk_btn.Location = new System.Drawing.Point(50, 263);
            this.Add_stk_btn.Name = "Add_stk_btn";
            this.Add_stk_btn.Size = new System.Drawing.Size(173, 35);
            this.Add_stk_btn.TabIndex = 5;
            this.Add_stk_btn.Text = "Add Stock";
            this.Add_stk_btn.UseVisualStyleBackColor = true;
            this.Add_stk_btn.Click += new System.EventHandler(this.Add_stk_btn_Click);
            // 
            // Remove_stk_btn
            // 
            this.Remove_stk_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Remove_stk_btn.Font = new System.Drawing.Font("HP Simplified", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Remove_stk_btn.Location = new System.Drawing.Point(50, 349);
            this.Remove_stk_btn.Name = "Remove_stk_btn";
            this.Remove_stk_btn.Size = new System.Drawing.Size(173, 35);
            this.Remove_stk_btn.TabIndex = 6;
            this.Remove_stk_btn.Text = "Remove stock";
            this.Remove_stk_btn.UseVisualStyleBackColor = true;
            this.Remove_stk_btn.Click += new System.EventHandler(this.button1_Click);
            // 
            // Options
            // 
            this.Options.AutoSize = true;
            this.Options.Font = new System.Drawing.Font("HP Simplified", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Options.ForeColor = System.Drawing.SystemColors.Highlight;
            this.Options.Location = new System.Drawing.Point(15, 81);
            this.Options.Name = "Options";
            this.Options.Size = new System.Drawing.Size(99, 28);
            this.Options.TabIndex = 7;
            this.Options.Text = "Options:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(256, 23);
            this.label3.TabIndex = 8;
            this.label3.Text = "Select one of the options below";
            this.label3.Click += new System.EventHandler(this.label3_Click_1);
            // 
            // Edit_emp_btn
            // 
            this.Edit_emp_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Edit_emp_btn.Font = new System.Drawing.Font("HP Simplified", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Edit_emp_btn.Location = new System.Drawing.Point(561, 262);
            this.Edit_emp_btn.Name = "Edit_emp_btn";
            this.Edit_emp_btn.Size = new System.Drawing.Size(215, 35);
            this.Edit_emp_btn.TabIndex = 9;
            this.Edit_emp_btn.Text = "Edit Employee details";
            this.Edit_emp_btn.UseVisualStyleBackColor = true;
            this.Edit_emp_btn.Click += new System.EventHandler(this.Edit_emp_btn_Click);
            // 
            // View_stk_btn
            // 
            this.View_stk_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.View_stk_btn.Font = new System.Drawing.Font("HP Simplified", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.View_stk_btn.Location = new System.Drawing.Point(561, 349);
            this.View_stk_btn.Name = "View_stk_btn";
            this.View_stk_btn.Size = new System.Drawing.Size(215, 35);
            this.View_stk_btn.TabIndex = 10;
            this.View_stk_btn.Text = "View Available Stock";
            this.View_stk_btn.UseVisualStyleBackColor = true;
            this.View_stk_btn.Click += new System.EventHandler(this.View_stk_btn_Click);
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("HP Simplified", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(302, 412);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(215, 35);
            this.button1.TabIndex = 11;
            this.button1.Text = "View Employees";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("HP Simplified", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(708, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 24);
            this.label4.TabIndex = 12;
            this.label4.Text = "label4";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("HP Simplified", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label5.Location = new System.Drawing.Point(398, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 41);
            this.label5.TabIndex = 13;
            this.label5.Text = "H.S Cafe";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Admin_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(840, 473);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.View_stk_btn);
            this.Controls.Add(this.Edit_emp_btn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Options);
            this.Controls.Add(this.Remove_stk_btn);
            this.Controls.Add(this.Add_stk_btn);
            this.Controls.Add(this.edit_admin_details_btn);
            this.Controls.Add(this.Add_emp_btn);
            this.Controls.Add(this.Username_Label);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.DoubleBuffered = true;
            this.Name = "Admin_Form";
            this.Text = "Cafe Management System - Administrator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Username_Label;
        private System.Windows.Forms.Button Add_emp_btn;
        private System.Windows.Forms.Button edit_admin_details_btn;
        private System.Windows.Forms.Button Add_stk_btn;
        private System.Windows.Forms.Button Remove_stk_btn;
        private System.Windows.Forms.Label Options;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Edit_emp_btn;
        private System.Windows.Forms.Button View_stk_btn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}


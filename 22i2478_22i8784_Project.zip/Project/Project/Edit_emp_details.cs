﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Edit_emp_details : Form
    {
        public Edit_emp_details()
        {
            InitializeComponent();
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {

            Form form = new Admin_Form();
            form.Show();
            this.Hide();

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //when enter is pressed search for employee id in database and then fill the fields with the data

            if (textBox1.Text == null)
            {
                MessageBox.Show("Please enter Employee ID");
            }
            else
            {

            }

        }

        private void F_emp_btn_Click(object sender, EventArgs e)
        {
            
            //when enter is pressed search for employee id in database and then fill the fields with the data

            if (textBox1.Text == null)
            {
                MessageBox.Show("Please enter Employee ID");
            }
            else
            {
                string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
                //search for employee id in database
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("SELECT * FROM Employee WHERE Employee_ID = @Employee_ID", con);
                    cmd.Parameters.AddWithValue("@Employee_ID", textBox1.Text);
                    
                    SqlCommand cmd2 = new SqlCommand("SELECT Gender FROM Employee WHERE Employee_ID = @Employee_ID", con);
                    cmd2.Parameters.AddWithValue("@Employee_ID", textBox1.Text);

                    //store gender in a string
                    string gender = cmd2.ExecuteScalar().ToString();

                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        f_name_tbox.Text = reader["F_Name"].ToString();
                        L_name_tbox.Text = reader["L_Name"].ToString();

                        if (gender == "Male")
                        {
                            male_rbtn.Checked = true;
                        }
                        else
                        {
                            female_rbtn.Checked = true;
                        }

                        pnum_tbox.Text = reader["PhoneNumber"].ToString();
                        email_tbox.Text = reader["Email"].ToString();
                    }


                }
                
            }
            
        }

        private void Edit_emp_details_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Add_emp_btn_Click(object sender, EventArgs e)
        {

            if (f_name_tbox.Text == null || L_name_tbox.Text == null || pnum_tbox.Text == null || email_tbox.Text == null || (male_rbtn.Checked==false && female_rbtn.Checked==false) ) { 
                

                MessageBox.Show("Please fill all fields");
            }
            else
            {
                string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE Employee SET F_Name = @F_Name," + "L_Name = @L_Name," + "Gender = @Gender," + "PhoneNumber = @PhoneNumber," + "Email = @Email," + "Salary = @Salary WHERE Employee_ID = @Employee_ID", con);
                    //get employee id from the text box1
                    cmd.Parameters.AddWithValue("@Employee_ID", textBox1.Text);

                    cmd.Parameters.AddWithValue("@F_Name", f_name_tbox.Text);
                    cmd.Parameters.AddWithValue("@L_Name", L_name_tbox.Text);

                    string gender = "";
                    
                    if(male_rbtn.Checked == true)
                    {
                        gender = "Male";
                    }
                    else
                    {
                        gender = "Female";
                    }

                    cmd.Parameters.AddWithValue("@Gender", gender);
                    cmd.Parameters.AddWithValue("@PhoneNumber", pnum_tbox.Text);
                    cmd.Parameters.AddWithValue("@Email", email_tbox.Text);
                    cmd.Parameters.AddWithValue("@Salary", Salary_Picker.Value.ToString());
                    cmd.ExecuteNonQuery();

                    
                }


                MessageBox.Show("Records Updated");
            }

            

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Add_Ingedients : Form
    {
        public Add_Ingedients()
        {
            InitializeComponent();
        }

        private void add_ing_btn_Click(object sender, EventArgs e)
        {
            if (ing_name_tbox.Text == null || Quantity_tbox.Text == null)
            {
                MessageBox.Show("Please fill all fields");
            }
            else
            {
                string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("INSERT INTO Item_Ingredients VALUES (@Ingredient_Name,@Item_ID, @Quantity)", con);
                    cmd.Parameters.AddWithValue("@Ingredient_Name", ing_name_tbox.Text);
                    cmd.Parameters.AddWithValue("@Item_ID", ItemID_tbox.Text);
                    cmd.Parameters.AddWithValue("@Quantity", Quantity_tbox.Text);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Ingredient Added Successfully");
            }

  
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            //move to add item
            Add_Items_Form add_Items_Form = new Add_Items_Form();
            add_Items_Form.Show();
            this.Hide();

        }
    }
}

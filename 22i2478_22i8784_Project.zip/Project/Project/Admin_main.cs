﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Admin_Form : Form
    {
        int admin_id;
       //create a parametrized constructor that get admin id
       public Admin_Form(int admin_id)
        {
            InitializeComponent();
            this.admin_id = admin_id;
            //label3.Text = admin_id.ToString();
        }

        public Admin_Form()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
             string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";

            //get the admin name from the database
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT F_name, L_name FROM Administrator WHERE Administrator_ID = @Admin_ID", con);
                cmd.Parameters.AddWithValue("@Admin_ID", admin_id);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    label4.Text = reader["F_name"].ToString() + " " + reader["L_name"].ToString();
                }
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {



        }

        private void Add_emp_btn_Click(object sender, EventArgs e)
        {
            //move to AddEmpForm
            AddEmpForm addEmpForm = new AddEmpForm();
            addEmpForm.Show();

            this.Hide();

            

        }

        private void Add_stk_btn_Click(object sender, EventArgs e)
        {
            //move to Add_Items_Form
            Add_Items_Form add_Items_Form = new Add_Items_Form();
            add_Items_Form.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //move to remove_items_form
            Remove_Item remove_Items_Form = new Remove_Item();
            remove_Items_Form.Show();
            this.Hide();

        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void edit_admin_details_btn_Click(object sender, EventArgs e)
        {
            //move to 
            Edit_admin_details_Form editAdminDetailsForm = new Edit_admin_details_Form(admin_id);
            editAdminDetailsForm.Show();
            this.Hide();
        }

        private void Edit_emp_btn_Click(object sender, EventArgs e)
        {

            Edit_emp_details edit_Emp_Details = new Edit_emp_details();
            edit_Emp_Details.Show();
            this.Hide();

        }

        private void View_stk_btn_Click(object sender, EventArgs e)
        {
            //move to View_Stock_Form
            ViewStock view_Stock_Form = new ViewStock();
            view_Stock_Form.Show();
            this.Hide();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //move to Emp_details_view
            Emp_details_view emp_Details_View = new Emp_details_view();
            emp_Details_View.Show();
            this.Hide();

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}

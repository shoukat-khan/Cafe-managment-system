﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Remove_Item : Form
    {
        public Remove_Item()
        {
            InitializeComponent();
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            Admin_Form admin_Form = new Admin_Form();
            admin_Form.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (item_ID_tbox.Text == null) { 
                MessageBox.Show("Please enter Item ID");
            }
            else
            {
                string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM Items WHERE Item_ID = @Item_ID", con);
                    cmd.Parameters.AddWithValue("@Item_ID", item_ID_tbox.Text);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Item Removed Successfully");

            }

        }
    }
}

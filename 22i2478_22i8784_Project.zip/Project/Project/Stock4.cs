﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Stock4 : Form
    {
        public Stock4()
        {
            InitializeComponent();
        }

        private void Stock4_Load(object sender, EventArgs e)
        {
            //get items with categories and ingredients
            string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT Items.item_id, Items.item_name, Items.price, Items.Quantity, Categories.Category_Name, Item_Ingredients.Ingredient_name" +
                    " FROM Items" +
                    " INNER JOIN Categories ON Items.Category_ID = Categories.Category_ID " +
                    "Left JOIN Item_Ingredients ON Item_Ingredients.Item_ID=Items.Item_id", con);

                SqlDataReader reader = cmd.ExecuteReader();
                
               DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView1.DataSource = dt;
                dataGridView1.Columns[0].HeaderText = "Item ID";
                dataGridView1.Columns[1].HeaderText = "Item Name";
                dataGridView1.Columns[2].HeaderText = "Price";
                dataGridView1.Columns[3].HeaderText = "Quantity";
                dataGridView1.Columns[4].HeaderText = "Category";
                dataGridView1.Columns[5].HeaderText = "Ingredients";

            }

           
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //move back to stock menu
            ViewStock sm = new ViewStock();
            sm.Show();
            this.Hide();

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
            //SELECT Items.item_id, Items.item_name, Items.price, Items.Quantity, Categories.Category_Name, COUNT(Item_Ingredients.Ingredient_name) AS 'Ingredients' FROM Items INNER JOIN Categories ON Items.Category_ID = Categories.Category_ID Left JOIN Item_Ingredients ON Item_Ingredients.Item_ID=Items.Item_id GROUP BY Items.item_id, Items.item_name, Items.price, Items.Quantity, Categories.Category_Name having count(Item_Ingredients.Ingredient_name)>1
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT Items.item_id, Items.item_name, Items.price, Items.Quantity, Categories.Category_Name, COUNT(Item_Ingredients.Ingredient_name) AS 'Ingredients'" +
                    " FROM Items INNER JOIN Categories ON Items.Category_ID = Categories.Category_ID" +
                    " Left JOIN Item_Ingredients ON Item_Ingredients.Item_ID=Items.Item_id" +
                    " GROUP BY Items.item_id, Items.item_name, Items.price, Items.Quantity, Categories.Category_Name", con);

                SqlDataReader reader = cmd.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView1.DataSource = dt;
                dataGridView1.Columns[0].HeaderText = "Item ID";
                dataGridView1.Columns[1].HeaderText = "Item Name";
                dataGridView1.Columns[2].HeaderText = "Price";
                dataGridView1.Columns[3].HeaderText = "Quantity";
                dataGridView1.Columns[4].HeaderText = "Category";
                dataGridView1.Columns[5].HeaderText = "Ingredients";

            }   
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
            //SELECT Items.item_id, Items.item_name, Items.price, Items.Quantity, Categories.Category_Name, COUNT(Item_Ingredients.Ingredient_name) AS 'Ingredients' FROM Items INNER JOIN Categories ON Items.Category_ID = Categories.Category_ID Left JOIN Item_Ingredients ON Item_Ingredients.Item_ID=Items.Item_id GROUP BY Items.item_id, Items.item_name, Items.price, Items.Quantity, Categories.Category_Name having count(Item_Ingredients.Ingredient_name)>1
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT Items.item_id, Items.item_name, Items.price, Items.Quantity, Categories.Category_Name, COUNT(Item_Ingredients.Ingredient_name) AS 'Ingredients'" +
                    " FROM Items INNER JOIN Categories ON Items.Category_ID = Categories.Category_ID" +
                    " Left JOIN Item_Ingredients ON Item_Ingredients.Item_ID=Items.Item_id" +
                    " GROUP BY Items.item_id, Items.item_name, Items.price, Items.Quantity, Categories.Category_Name" +
                    " having count(Item_Ingredients.Ingredient_name)>1", con);

                SqlDataReader reader = cmd.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView1.DataSource = dt;
                dataGridView1.Columns[0].HeaderText = "Item ID";
                dataGridView1.Columns[1].HeaderText = "Item Name";
                dataGridView1.Columns[2].HeaderText = "Price";
                dataGridView1.Columns[3].HeaderText = "Quantity";
                dataGridView1.Columns[4].HeaderText = "Category";
                dataGridView1.Columns[5].HeaderText = "Ingredients";

            }
        }
    }
}

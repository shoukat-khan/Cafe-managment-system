﻿namespace database_project
{
    partial class Order_placment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label10 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.search_box = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.selected_quantity = new System.Windows.Forms.NumericUpDown();
            this.Add_to_cart = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.Grand_Total_label = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.Confirm_order = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.total_label = new System.Windows.Forms.Label();
            this.price_label = new System.Windows.Forms.Label();
            this.Orders = new System.Windows.Forms.DataGridView();
            this.Items = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Item_Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantiti_item = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sub_total_Item = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name_label = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Items_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.single_Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Items_quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.selected_quantity)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Orders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(783, 4);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 37);
            this.label10.TabIndex = 39;
            this.label10.Text = "❎";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(726, 426);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(97, 29);
            this.button2.TabIndex = 34;
            this.button2.Text = "Confirm order";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Font = new System.Drawing.Font("HP Simplified", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(89, 8);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 37);
            this.label1.TabIndex = 19;
            this.label1.Text = "Place order";
            // 
            // search_box
            // 
            this.search_box.Location = new System.Drawing.Point(0, 96);
            this.search_box.Margin = new System.Windows.Forms.Padding(2);
            this.search_box.Multiline = true;
            this.search_box.Name = "search_box";
            this.search_box.Size = new System.Drawing.Size(159, 28);
            this.search_box.TabIndex = 22;
            this.search_box.TextChanged += new System.EventHandler(this.search_box_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label3.Location = new System.Drawing.Point(307, 100);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 23);
            this.label3.TabIndex = 24;
            this.label3.Text = "Quantity";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label4.Location = new System.Drawing.Point(307, 41);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 23);
            this.label4.TabIndex = 25;
            this.label4.Text = "Item name ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label5.Location = new System.Drawing.Point(591, 41);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 23);
            this.label5.TabIndex = 26;
            this.label5.Text = "Price";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label6.Location = new System.Drawing.Point(591, 93);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 23);
            this.label6.TabIndex = 27;
            this.label6.Text = "Total";
            // 
            // selected_quantity
            // 
            this.selected_quantity.Location = new System.Drawing.Point(310, 124);
            this.selected_quantity.Margin = new System.Windows.Forms.Padding(2);
            this.selected_quantity.Name = "selected_quantity";
            this.selected_quantity.Size = new System.Drawing.Size(90, 20);
            this.selected_quantity.TabIndex = 31;
            // 
            // Add_to_cart
            // 
            this.Add_to_cart.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_to_cart.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Add_to_cart.Location = new System.Drawing.Point(522, 156);
            this.Add_to_cart.Margin = new System.Windows.Forms.Padding(2);
            this.Add_to_cart.Name = "Add_to_cart";
            this.Add_to_cart.Size = new System.Drawing.Size(116, 34);
            this.Add_to_cart.TabIndex = 32;
            this.Add_to_cart.Text = "Add to cart";
            this.Add_to_cart.UseVisualStyleBackColor = true;
            this.Add_to_cart.Click += new System.EventHandler(this.Add_to_cart_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label8.Location = new System.Drawing.Point(4, 69);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(132, 23);
            this.label8.TabIndex = 20;
            this.label8.Text = "Search Product";
            // 
            // Grand_Total_label
            // 
            this.Grand_Total_label.AutoSize = true;
            this.Grand_Total_label.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Grand_Total_label.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Grand_Total_label.Location = new System.Drawing.Point(414, 428);
            this.Grand_Total_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Grand_Total_label.Name = "Grand_Total_label";
            this.Grand_Total_label.Size = new System.Drawing.Size(36, 23);
            this.Grand_Total_label.TabIndex = 36;
            this.Grand_Total_label.Text = "0.0";
            this.Grand_Total_label.Click += new System.EventHandler(this.Total_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(312, 428);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 23);
            this.label7.TabIndex = 35;
            this.label7.Text = "Grand Total";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label9.Location = new System.Drawing.Point(2, 133);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 23);
            this.label9.TabIndex = 37;
            this.label9.Text = "Item List";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 39);
            this.label11.TabIndex = 38;
            this.label11.Text = "⬅\r\n";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // Confirm_order
            // 
            this.Confirm_order.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Confirm_order.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Confirm_order.Location = new System.Drawing.Point(659, 422);
            this.Confirm_order.Margin = new System.Windows.Forms.Padding(2);
            this.Confirm_order.Name = "Confirm_order";
            this.Confirm_order.Size = new System.Drawing.Size(146, 32);
            this.Confirm_order.TabIndex = 39;
            this.Confirm_order.Text = "Confirm order";
            this.Confirm_order.UseVisualStyleBackColor = true;
            this.Confirm_order.Click += new System.EventHandler(this.button3_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.total_label);
            this.panel1.Controls.Add(this.price_label);
            this.panel1.Controls.Add(this.Orders);
            this.panel1.Controls.Add(this.name_label);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.Confirm_order);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.Grand_Total_label);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.Add_to_cart);
            this.panel1.Controls.Add(this.selected_quantity);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.search_box);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(2, 1);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(830, 468);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(454, 428);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 23);
            this.label2.TabIndex = 45;
            this.label2.Text = "Rs";
            // 
            // total_label
            // 
            this.total_label.AutoSize = true;
            this.total_label.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.total_label.ForeColor = System.Drawing.SystemColors.ControlText;
            this.total_label.Location = new System.Drawing.Point(592, 111);
            this.total_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.total_label.Name = "total_label";
            this.total_label.Size = new System.Drawing.Size(0, 19);
            this.total_label.TabIndex = 44;
            // 
            // price_label
            // 
            this.price_label.AutoSize = true;
            this.price_label.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.price_label.ForeColor = System.Drawing.SystemColors.ControlText;
            this.price_label.Location = new System.Drawing.Point(591, 67);
            this.price_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.price_label.Name = "price_label";
            this.price_label.Size = new System.Drawing.Size(0, 19);
            this.price_label.TabIndex = 43;
            // 
            // Orders
            // 
            this.Orders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Orders.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Items,
            this.Item_Price,
            this.Quantiti_item,
            this.Sub_total_Item});
            this.Orders.Location = new System.Drawing.Point(301, 199);
            this.Orders.Margin = new System.Windows.Forms.Padding(2);
            this.Orders.Name = "Orders";
            this.Orders.RowHeadersWidth = 51;
            this.Orders.RowTemplate.Height = 24;
            this.Orders.Size = new System.Drawing.Size(504, 213);
            this.Orders.TabIndex = 40;
            // 
            // Items
            // 
            this.Items.HeaderText = "items";
            this.Items.MinimumWidth = 6;
            this.Items.Name = "Items";
            this.Items.Width = 125;
            // 
            // Item_Price
            // 
            this.Item_Price.HeaderText = "Price";
            this.Item_Price.MinimumWidth = 6;
            this.Item_Price.Name = "Item_Price";
            this.Item_Price.Width = 125;
            // 
            // Quantiti_item
            // 
            this.Quantiti_item.HeaderText = "Quantity";
            this.Quantiti_item.MinimumWidth = 6;
            this.Quantiti_item.Name = "Quantiti_item";
            this.Quantiti_item.Width = 125;
            // 
            // Sub_total_Item
            // 
            this.Sub_total_Item.HeaderText = "Sub_total";
            this.Sub_total_Item.MinimumWidth = 6;
            this.Sub_total_Item.Name = "Sub_total_Item";
            this.Sub_total_Item.Width = 125;
            // 
            // name_label
            // 
            this.name_label.AutoSize = true;
            this.name_label.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name_label.ForeColor = System.Drawing.SystemColors.ControlText;
            this.name_label.Location = new System.Drawing.Point(307, 67);
            this.name_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.name_label.Name = "name_label";
            this.name_label.Size = new System.Drawing.Size(0, 19);
            this.name_label.TabIndex = 42;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Items_name,
            this.single_Price,
            this.Items_quantity});
            this.dataGridView1.Location = new System.Drawing.Point(2, 156);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(294, 306);
            this.dataGridView1.TabIndex = 41;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Items_name
            // 
            this.Items_name.HeaderText = "Name";
            this.Items_name.MinimumWidth = 6;
            this.Items_name.Name = "Items_name";
            this.Items_name.Width = 125;
            // 
            // single_Price
            // 
            this.single_Price.HeaderText = "Price";
            this.single_Price.MinimumWidth = 6;
            this.single_Price.Name = "single_Price";
            this.single_Price.Width = 125;
            // 
            // Items_quantity
            // 
            this.Items_quantity.HeaderText = "Quantity";
            this.Items_quantity.MinimumWidth = 6;
            this.Items_quantity.Name = "Items_quantity";
            this.Items_quantity.Width = 125;
            // 
            // Order_placment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 468);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button2);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Order_placment";
            this.Text = "Order_placment";
            this.Load += new System.EventHandler(this.Order_placment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.selected_quantity)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Orders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox search_box;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown selected_quantity;
        private System.Windows.Forms.Button Add_to_cart;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label Grand_Total_label;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button Confirm_order;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView Orders;
        private System.Windows.Forms.DataGridViewTextBoxColumn Items;
        private System.Windows.Forms.DataGridViewTextBoxColumn Item_Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantiti_item;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sub_total_Item;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Items_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn single_Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Items_quantity;
        private System.Windows.Forms.Label total_label;
        private System.Windows.Forms.Label price_label;
        private System.Windows.Forms.Label name_label;
        private System.Windows.Forms.Label label2;
    }
}
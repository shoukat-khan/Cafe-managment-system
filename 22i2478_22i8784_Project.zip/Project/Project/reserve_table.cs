﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace database_project
{
    
    public partial class reserve_table : Form
    {

         string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        int id;

        public reserve_table()
        {
            InitializeComponent();
        }
        //constructor that has the customer id
        public reserve_table(int customer_id)
        {
            InitializeComponent();
            id = customer_id;
        }

        private void Table_1_Paint(object sender, PaintEventArgs e)
        {
           
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                // Check if the table is already reserved
                string query = "select count(*) from Table_Reservations where table_Num =1";
                SqlCommand cmd = new SqlCommand(query, con);
                int count = (int)cmd.ExecuteScalar();
                if (count == 1)
                {
                    table1_status.Text = "reserved";
                }
                else
                {
                    table1_status.Text = "available";
                }


                if (table1_status.Text == "reserved")
                {
                    Table_1.BackColor = Color.Red;
                }
                else
                {
                    Table_1.BackColor = Color.Green;
                    Table_1.Click += Table_1_Click; // Only allow click event if the table is available
                }
            }
        }

        private void Table_1_Click(object sender, EventArgs e)
        {
            int reservedTablesCount;
            if (Table_1.BackColor == Color.Green) // Check if the table is available (green)
            {
                 string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    // Check the number of tables already reserved by the customer
                    string query = "SELECT COUNT(*) FROM Table_Reservations WHERE Customer_ID = @CustomerId";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID

                     reservedTablesCount = (int)cmd.ExecuteScalar();

                    if (reservedTablesCount == 0) // Check if the customer hasn't reserved any table yet
                    {
                        // Reserve the table
                        string reserveQuery = "INSERT INTO Table_Reservations (Customer_ID, table_Num, Reservation_Date, Reservation_Time) VALUES (@CustomerId, 1, GETDATE(), CONVERT(time, GETDATE()))";
                        SqlCommand reserveCmd = new SqlCommand(reserveQuery, con);
                        reserveCmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID
                        reserveCmd.ExecuteNonQuery();

                        // Update UI to reflect reservation
                        table1_status.Text = "reserved";
                        Table_1.Text = "reserved";
                        Table_1.BackColor = Color.Red;
                       
                    }
                    else 
                    {
                        MessageBox.Show("You have already reserved a table.");
                        return;
                    }
                }
            }
           


        }

        private void Table_2_Paint(object sender, PaintEventArgs e)
        {
            //same as the above code
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "select count(*) from Table_Reservations where table_Num =2";
                SqlCommand cmd = new SqlCommand(query, con);
                int count = (int)cmd.ExecuteScalar();
                if (count == 1)
                {
                    table2_status.Text = "reserved";
                }
                else
                {
                    table2_status.Text = "available";
                }
            }
            if (table2_status.Text == "reserved")
            {
                Table_2.BackColor = Color.Red;
            }
            else
            {
                Table_2.BackColor = Color.Green;
                Table_2.Click += Table_2_Click;
            }
            

       
        }
        private void Table_2_Click(object sender, EventArgs e)
        {
            if (Table_2.BackColor == Color.Green)
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "SELECT COUNT(*) FROM Table_Reservations WHERE Customer_ID = @CustomerId";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID

                    int reservedTablesCount = (int)cmd.ExecuteScalar();

                    if (reservedTablesCount == 0) // Check if the customer hasn't reserved any table yet
                    {
                        string reserveQuery = "INSERT INTO Table_Reservations (Customer_ID, table_Num, Reservation_Date, Reservation_Time) VALUES (@CustomerId, 2, GETDATE(), CONVERT(time, GETDATE()))";
                        SqlCommand reserveCmd = new SqlCommand(reserveQuery, con);
                        reserveCmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID
                        reserveCmd.ExecuteNonQuery();

                        table2_status.Text = "reserved";
                        Table_2.Text = "reserved";
                        Table_2.BackColor = Color.Red;
                    }
                    else
                    {
                        MessageBox.Show("You have already reserved a table.");
                        return;
                    }
                }
            }
           
        }

        private void Table_3_Paint(object sender, PaintEventArgs e)
        {
            //same as the above
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "select count(*) from Table_Reservations where table_Num =3";
                SqlCommand cmd = new SqlCommand(query, con);
                int count = (int)cmd.ExecuteScalar();
                if (count == 1)
                {
                    table3_status.Text = "reserved";
                }
                else
                {
                    table3_status.Text = "available";
                }
                
            }
            if (table3_status.Text == "reserved")
            {
                Table_3.BackColor = Color.Red;
            }
            else
            {
                Table_3.BackColor = Color.Green;
                Table_3.Click += Table_3_Click;
            }

        }
        private void Table_3_Click(object sender, EventArgs e)
        {
            if (Table_3.BackColor == Color.Green)
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "SELECT COUNT(*) FROM Table_Reservations WHERE Customer_ID = @CustomerId";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID

                    int reservedTablesCount = (int)cmd.ExecuteScalar();

                    if (reservedTablesCount == 0) // Check if the customer hasn't reserved any table yet
                    {
                        string reserveQuery = "INSERT INTO Table_Reservations (Customer_ID, table_Num, Reservation_Date, Reservation_Time) VALUES (@CustomerId, 2, GETDATE(), CONVERT(time, GETDATE()))";
                        SqlCommand reserveCmd = new SqlCommand(reserveQuery, con);
                        reserveCmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID
                        reserveCmd.ExecuteNonQuery();

                        table3_status.Text = "reserved";
                        Table_3.Text = "reserved";
                        Table_3.BackColor = Color.Red;
                    }
                    else
                    {
                        MessageBox.Show("You have already reserved a table.");
                        return;
                    }
                }
            }

        }

        private void Table_4_Paint(object sender, PaintEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "select count(*) from Table_Reservations where table_Num =4";
                SqlCommand cmd = new SqlCommand(query, con);
                int count = (int)cmd.ExecuteScalar();
                if (count == 1)
                {
                    table4_status.Text = "reserved";
                }
                else
                {
                    table4_status.Text = "available";
                }

            }
            if (table4_status.Text == "reserved")
            {
                Table_4.BackColor = Color.Red;
            }
            else
            {
                Table_4.BackColor = Color.Green;
                Table_4.Click += Table_4_Click;
            }

        }
        private void Table_4_Click(object sender, EventArgs e)
        {
            //same as the above
            if (Table_4.BackColor == Color.Green)
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "SELECT COUNT(*) FROM Table_Reservations WHERE Customer_ID = @CustomerId";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID

                    int reservedTablesCount = (int)cmd.ExecuteScalar();

                    if (reservedTablesCount == 0) // Check if the customer hasn't reserved any table yet
                    {
                        string reserveQuery = "INSERT INTO Table_Reservations (Customer_ID, table_Num, Reservation_Date, Reservation_Time) VALUES (@CustomerId, 2, GETDATE(), CONVERT(time, GETDATE()))";
                        SqlCommand reserveCmd = new SqlCommand(reserveQuery, con);
                        reserveCmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID
                        reserveCmd.ExecuteNonQuery();

                        table4_status.Text = "reserved";
                        Table_4.Text = "reserved";
                        Table_4.BackColor = Color.Red;
                    }
                    else
                    {
                        MessageBox.Show("You have already reserved a table.");
                        return;
                    }
                }
            }
            
        }

        private void Table_5_Paint(object sender, PaintEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "select count(*) from Table_Reservations where table_Num =5";
                SqlCommand cmd = new SqlCommand(query, con);
                int count = (int)cmd.ExecuteScalar();
                if (count == 1)
                {
                    table5_status.Text = "reserved";
                }
                else
                {
                    table5_status.Text = "available";
                }

            }
            if (table5_status.Text == "reserved")
            {
                Table_5.BackColor = Color.Red;
            }
            else
            {
                Table_5.BackColor = Color.Green;
                Table_5.Click += Table_5_Click;
            }
            

        }
        private void Table_5_Click(object sender, EventArgs e)
        {
            if (Table_5.BackColor == Color.Green)
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "SELECT COUNT(*) FROM Table_Reservations WHERE Customer_ID = @CustomerId";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID

                    int reservedTablesCount = (int)cmd.ExecuteScalar();

                    if (reservedTablesCount == 0) // Check if the customer hasn't reserved any table yet
                    {
                        string reserveQuery = "INSERT INTO Table_Reservations (Customer_ID, table_Num, Reservation_Date, Reservation_Time) VALUES (@CustomerId, 2, GETDATE(), CONVERT(time, GETDATE()))";
                        SqlCommand reserveCmd = new SqlCommand(reserveQuery, con);
                        reserveCmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID
                        reserveCmd.ExecuteNonQuery();

                        table5_status.Text = "reserved";
                        Table_5.Text = "reserved";
                        Table_5.BackColor = Color.Red;
                    }
                    else
                    {
                        MessageBox.Show("You have already reserved a table.");
                        return;
                    }
                }
            }
           
        }

        private void Table_6_Paint(object sender, PaintEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "select count(*) from Table_Reservations where table_Num =6";
                SqlCommand cmd = new SqlCommand(query, con);
                int count = (int)cmd.ExecuteScalar();
                if (count == 1)
                {
                    table6_status.Text = "reserved";
                }
                else
                {
                    table6_status.Text = "available";
                }

            }
            if (table6_status.Text == "reserved")
            {
                Table_6.BackColor = Color.Red;
            }
            else
            {
                Table_6.BackColor = Color.Green;
                Table_6.Click += Table_6_Click;
            }
            

        }
        private void Table_6_Click(object sender, EventArgs e)
        {
            if (Table_6.BackColor == Color.Green)
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "SELECT COUNT(*) FROM Table_Reservations WHERE Customer_ID = @CustomerId";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID

                    int reservedTablesCount = (int)cmd.ExecuteScalar();

                    if (reservedTablesCount == 0) // Check if the customer hasn't reserved any table yet
                    {
                        string reserveQuery = "INSERT INTO Table_Reservations (Customer_ID, table_Num, Reservation_Date, Reservation_Time) VALUES (@CustomerId, 2, GETDATE(), CONVERT(time, GETDATE()))";
                        SqlCommand reserveCmd = new SqlCommand(reserveQuery, con);
                        reserveCmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID
                        reserveCmd.ExecuteNonQuery();

                        table6_status.Text = "reserved";
                        Table_6.Text = "reserved";
                        Table_6.BackColor = Color.Red;
                    }
                    else
                    {
                        MessageBox.Show("You have already reserved a table.");
                        return;
                    }
                }
            }
            
        }

        private void Table_7_Paint(object sender, PaintEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "select count(*) from Table_Reservations where table_Num =7";
                SqlCommand cmd = new SqlCommand(query, con);
                int count = (int)cmd.ExecuteScalar();
                if (count == 1)
                {
                    table7_status.Text = "reserved";
                }
                else
                {
                    table7_status.Text = "available";
                }

            }
            if (table7_status.Text == "reserved")
            {
                Table_7.BackColor = Color.Red;
            }
            else
            {
                Table_7.BackColor = Color.Green;
                Table_7.Click += Table_7_Click;
            }
            
        }
            private void Table_7_Click(object sender, EventArgs e)
        {
            if (Table_7.BackColor == Color.Green)
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "SELECT COUNT(*) FROM Table_Reservations WHERE Customer_ID = @CustomerId";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID

                    int reservedTablesCount = (int)cmd.ExecuteScalar();

                    if (reservedTablesCount == 0) // Check if the customer hasn't reserved any table yet
                    {
                        string reserveQuery = "INSERT INTO Table_Reservations (Customer_ID, table_Num, Reservation_Date, Reservation_Time) VALUES (@CustomerId, 2, GETDATE(), CONVERT(time, GETDATE()))";
                        SqlCommand reserveCmd = new SqlCommand(reserveQuery, con);
                        reserveCmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID
                        reserveCmd.ExecuteNonQuery();

                        table7_status.Text = "reserved";
                        Table_7.Text = "reserved";
                        Table_7.BackColor = Color.Red;
                    }
                    else
                    {
                        MessageBox.Show("You have already reserved a table.");
                        return;
                    }
                }
            }
          
        }

        private void Table_8_Paint(object sender, PaintEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "select count(*) from Table_Reservations where table_Num =8";
                SqlCommand cmd = new SqlCommand(query, con);
                int count = (int)cmd.ExecuteScalar();
                if (count == 1)
                {
                    table8_status.Text = "reserved";
                }
                else
                {
                    table8_status.Text = "available";
                }

            }
            if (table8_status.Text == "reserved")
            {
                Table_8.BackColor = Color.Red;
            }
            else
            {
                Table_8.BackColor = Color.Green;
                Table_8.Click += Table_8_Click;
            }
           

        }
        private void Table_8_Click(object sender, EventArgs e)
        {
            if (Table_8.BackColor == Color.Green)
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "SELECT COUNT(*) FROM Table_Reservations WHERE Customer_ID = @CustomerId";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID

                    int reservedTablesCount = (int)cmd.ExecuteScalar();

                    if (reservedTablesCount == 0) // Check if the customer hasn't reserved any table yet
                    {
                        string reserveQuery = "INSERT INTO Table_Reservations (Customer_ID, table_Num, Reservation_Date, Reservation_Time) VALUES (@CustomerId, 2, GETDATE(), CONVERT(time, GETDATE()))";
                        SqlCommand reserveCmd = new SqlCommand(reserveQuery, con);
                        reserveCmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID
                        reserveCmd.ExecuteNonQuery();

                        table8_status.Text = "reserved";
                        Table_8.Text = "reserved";
                        Table_8.BackColor = Color.Red;
                    }
                    else
                    {
                        MessageBox.Show("You have already reserved a table.");
                        return;
                    }
                }
            }
           
        }

        private void Table_9_Paint(object sender, PaintEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "select count(*) from Table_Reservations where table_Num =9";
                SqlCommand cmd = new SqlCommand(query, con);
                int count = (int)cmd.ExecuteScalar();
                if (count == 1)
                {
                    table9_status.Text = "reserved";
                }
                else
                {
                    table9_status.Text = "available";
                }

            }
            if (table9_status.Text == "reserved")
            {
                Table_9.BackColor = Color.Red;
            }
            else
            {
                Table_9.BackColor = Color.Green;
                Table_9.Click += Table_9_Click;
            }
            

        }
        private void Table_9_Click(object sender, EventArgs e)
        {
            if (Table_9.BackColor == Color.Green)
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "SELECT COUNT(*) FROM Table_Reservations WHERE Customer_ID = @CustomerId";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID

                    int reservedTablesCount = (int)cmd.ExecuteScalar();

                    if (reservedTablesCount == 0) // Check if the customer hasn't reserved any table yet
                    {
                        string reserveQuery = "INSERT INTO Table_Reservations (Customer_ID, table_Num, Reservation_Date, Reservation_Time) VALUES (@CustomerId, 2, GETDATE(), CONVERT(time, GETDATE()))";
                        SqlCommand reserveCmd = new SqlCommand(reserveQuery, con);
                        reserveCmd.Parameters.AddWithValue("@CustomerId", id); // Assuming id is the customer ID
                        reserveCmd.ExecuteNonQuery();

                        table9_status.Text = "reserved";
                        Table_9.Text = "reserved";
                        Table_9.BackColor = Color.Red;
                    }
                    else
                    {
                        MessageBox.Show("You have already reserved a table.");
                        return;
                    }
                }
            }
            
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void reserve_table_Load(object sender, EventArgs e)
        {

           

        }

        private void label13_Click(object sender, EventArgs e)
        {
           // back to the previous form
           con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand("select F_name, L_name from Customer where Customer_ID = " + id, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            string name = dr["F_name"].ToString() + " " + dr["L_name"].ToString();
            customer_dashboard f = new customer_dashboard(id, name);
            f.Show();
            this.Hide();
          
          


        }

        private void label12_Click(object sender, EventArgs e)
        {
            //exit application
            Application.Exit();


        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace database_project
{

    public partial class View_previous_orders : Form
    {
         string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        int Customer_id = 1;
        //add three table join for all queries
        //qury to assign name to Customer_name_label
        

       
        //constructor that has the customer id
        public View_previous_orders(int customer_id)
        {
            InitializeComponent();
            Customer_id = customer_id;

            

        }


        private void View_previous_orders_Load(object sender, EventArgs e)
        {
            try { 
            //query to get all orders of customer
            con = new SqlConnection(connectionString);
            con.Open();
            //select F_name, L_name from Customer where Customer_ID = 1
            cmd = new SqlCommand("select F_name, L_name from Customer where Customer_ID = " + Customer_id, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            Customer_name_label.Text = dr["F_name"].ToString() + " " + dr["L_name"].ToString();
            dr.Close();

            //grid view to show all orders
            grid_view();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void grid_view()
        {

            //select i.item_name,i.price,oi.Quantity, ca.Category_name ,o.Order_date from Orders o join Order_Items oi on o.Order_ID = oi.Order_ID  join Customer c 
            //on o.Customer_ID = c.Customer_ID join Items i on oi.Item_ID = i.Item_ID join Categories ca on i.Category_ID = ca.Category_ID
            //where c.Customer_ID = 1
            cmd = new SqlCommand("select i.item_name,i.price,oi.Quantity, ca.Category_name ,o.Order_date from Orders o join Order_Items oi on o.Order_ID = oi.Order_ID  join Customer c on o.Customer_ID = c.Customer_ID join Items i on oi.Item_ID = i.Item_ID join Categories ca on i.Category_ID = ca.Category_ID where c.Customer_ID = " + Customer_id, con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            dr.Close();



        }

        private void last_day_order_btn_CheckedChanged(object sender, EventArgs e)
        {

            cmd = new SqlCommand("select i.item_name,i.price,oi.Quantity, ca.Category_name ,o.Order_date from Orders o " +
                "join Order_Items oi on o.Order_ID = oi.Order_ID" +
                " join Customer c on o.Customer_ID = c.Customer_ID" +
                " join Items i on oi.Item_ID = i.Item_ID" +
                " join Categories ca on i.Category_ID = ca.Category_ID where c.Customer_ID = " + Customer_id + "" +
                " and o.Order_date = (select max(Order_date) from Orders where Customer_ID = " + Customer_id + ")", con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            dr.Close();
           



        }

        private void Last_week_order_btn_CheckedChanged(object sender, EventArgs e)
        {
//            CREATE OR ALTER PROCEDURE get_last_week_order_details
//            @Customer_ID INT
//AS
//BEGIN
//    -- Check if the view exists, drop it if it does
//    IF OBJECT_ID('last_week_order_details', 'V') IS NOT NULL
//        DROP VIEW last_week_order_details;

//            --Create the view

//    DECLARE @sql NVARCHAR(MAX);
//            SET @sql = '

//        CREATE VIEW last_week_order_details AS

//        SELECT

//            i.item_name,
//			i.price,
//			oi.Quantity,
//			ca.Category_name,
//			o.Order_date
//        FROM Orders o

//        JOIN Order_Items oi ON o.Order_ID = oi.Order_ID

//        JOIN Customer c ON o.Customer_ID = c.Customer_ID

//        JOIN Items i ON oi.Item_ID = i.Item_ID

//        JOIN Categories ca ON i.Category_ID = ca.Category_ID

//        WHERE o.Order_date >= DATEADD(WEEK, -1, GETDATE())

//            AND o.Order_date <= GETDATE()

//            AND c.Customer_ID = ' + CONVERT(NVARCHAR(10), @Customer_ID) + ';
//            ';

//    EXEC sp_executesql @sql;
//            END;


            cmd = new SqlCommand("get_last_week_order_details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Customer_ID", Customer_id);
            cmd.ExecuteNonQuery();

            cmd = new SqlCommand("select * from last_week_order_details", con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            dr.Close();

        }

        private void last_month_order_btn_CheckedChanged(object sender, EventArgs e)
        {

//            CREATE OR ALTER PROCEDURE get_last_month_order_details
//@Customer_ID INT
//AS
//BEGIN
//    -- Check if the view exists, drop it if it does
//    IF OBJECT_ID('last_month_order_details', 'V') IS NOT NULL
//        DROP VIEW last_month_order_details;

//            --Create the view
//    DECLARE @sql NVARCHAR(MAX);
//            SET @sql = '
//        CREATE VIEW last_month_order_details AS
//        SELECT
//            i.item_name,
//            i.price,
//            oi.Quantity,
//            ca.Category_name,
//            o.Order_date
//        FROM Orders o
//        JOIN Order_Items oi ON o.Order_ID = oi.Order_ID
//        JOIN Customer c ON o.Customer_ID = c.Customer_ID
//        JOIN Items i ON oi.Item_ID = i.Item_ID
//        JOIN Categories ca ON i.Category_ID = ca.Category_ID
//        WHERE o.Order_date >= DATEADD(MONTH, -1, DATEADD(DAY, 1, EOMONTH(GETDATE(), -1)))
//            AND o.Order_date <= EOMONTH(GETDATE())
//            AND c.Customer_ID = ' + CONVERT(NVARCHAR(10), @Customer_ID) + ';
//            ';
//    EXEC sp_executesql @sql;
//            END;

            cmd = new SqlCommand("get_last_month_order_details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Customer_ID", Customer_id);
            cmd.ExecuteNonQuery();

            cmd = new SqlCommand("select * from last_month_order_details", con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            dr.Close();


        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {
            try { 
            //move back to the customer dashboard
            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand("select F_name, L_name from Customer where Customer_ID = " + Customer_id, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            string name = dr["F_name"].ToString() + " " + dr["L_name"].ToString();
            customer_dashboard f = new customer_dashboard(Customer_id, name);
            f.Show();
            this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}

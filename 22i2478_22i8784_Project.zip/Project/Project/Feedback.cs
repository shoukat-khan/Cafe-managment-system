﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class Feedback : Form
    {
         string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        int Customer_id = 1;
       
        public Feedback(int customer_id)
        {
            InitializeComponent();
            Customer_id = customer_id;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //check that the selected column is not the header or is not the empty row
            // if the above condition is true then in the selected_item_label assign the row[1] to the label 
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                Item_name.Text = row.Cells[1].Value.ToString();
                id_label.Text = row.Cells[0].Value.ToString();
            }



        }

        private void Feedback_Load(object sender, EventArgs e)
        {
            //
            grid_view();
        }
        private void grid_view()
        {
            //select * from Items
            con = new SqlConnection(connectionString);
            con.Open();
            //show only the items that are bought by the customer
            //select i.Item_id, i.item_name, i.price
            //from
            //Customer c join Orders o on c.customer_id = o.customer_id
            //join Order_Items oi on o.order_id = oi.order_id
            //join Items i on oi.item_id = i.item_id
            //where c.customer_id = 1
            cmd = new SqlCommand("select i.Item_id, i.item_name, i.price from Customer c join Orders o on c.customer_id = o.customer_id join Order_Items oi on o.order_id = oi.order_id join Items i on oi.item_id = i.item_id where c.customer_id = " + Customer_id, con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            dr.Close();


        }

        private void search_box_TextChanged(object sender, EventArgs e)
        {

       
            try
            {
                string search = search_box.Text;
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    if (dataGridView1.Rows[i].Cells[1].Value.ToString().Contains(search))
                    {
                        dataGridView1.Rows[i].Visible = true;
                    }
                    else
                    {
                        dataGridView1.Rows[i].Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }

        private void label_Click(object sender, EventArgs e)
        {

        }

        private void Submit_feedback_Click(object sender, EventArgs e)
        {
            //check if the rating is empty or not and if the recommendation is empty or not
            if (Rating.Text == "" || textBox1.Text == "" || id_label.Text==""|| Item_name.Text=="")
            {
                MessageBox.Show("Please fill all the fields");
            }
            else
            {
                //insert the feedback into the feedback table
                con = new SqlConnection(connectionString);
                con.Open();
                
               // insert into Reviews(Customer_ID, Item_ID, rating, Recommendation) values(1, 1, 5, 'Great product')
               cmd = new SqlCommand("insert into Reviews(Customer_ID, Item_ID, rating, Recommendation) values(" + Customer_id + "," + Convert.ToInt32(id_label.Text) + "," + Convert.ToInt32(Rating.Text) + ",'" + textBox1.Text + "')", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Feedback Submitted");
                con.Close();
                //clear the textboxes
                Rating.Text = "";
                textBox1.Text = "";
                id_label.Text = "";
                Item_name.Text = "";


            }   

        }

        private void label5_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand("select F_name, L_name from Customer where Customer_ID = " + Customer_id, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            string name = dr["F_name"].ToString() + " " + dr["L_name"].ToString();
            customer_dashboard f = new customer_dashboard(Customer_id, name);
            f.Show();
            this.Hide();

        }

        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }
}

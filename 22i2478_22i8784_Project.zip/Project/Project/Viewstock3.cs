﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Viewstock3 : Form
    {
        public Viewstock3()
        {
            InitializeComponent();
        }

        private void Viewstock3_Load(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                //add headers to the table
                tableLayoutPanel1.Controls.Add(new Label() { Text = "Item Name" });
                tableLayoutPanel1.Controls.Add(new Label() { Text = "Category" });

                SqlCommand cmd = new SqlCommand("Select I.item_name, C.Category_name from Items I join Categories c ON I.Category_id=C.Category_id", con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    //add items to the table
                    
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["Item_Name"].ToString() });
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["Category_Name"].ToString() });



                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //move to viewstock
            ViewStock viewstock = new ViewStock();
            viewstock.Show();
            this.Hide();
        }
    }
}

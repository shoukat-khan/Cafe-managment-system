﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class OrderReports : Form
    {

        string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        int sellerId;

        public OrderReports(int sellerId)
        {
            InitializeComponent();
            this.sellerId = sellerId;
        }

        public OrderReports()
        {
            InitializeComponent();
        }

        private void OrderReports_Load(object sender, EventArgs e)
        {

            //display all orders in the datagridview
            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand("select * from Orders", con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;


        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            //move back to seller dashboard
            Seller_dashboard seller_Dashboard = new Seller_dashboard(sellerId);
            seller_Dashboard.Show();
            this.Hide();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //clear the datagridview
            dataGridView1.DataSource = null;

            string query = "select C.F_name, O.Order_date, OI.*, it.item_name from Customer C" +
                " JOIN Orders O ON C.Customer_ID = O.Customer_ID" +
                " JOIN Order_Items OI ON O.Order_ID = OI.Order_ID" +
                " JOIN Items it ON it.Item_id = OI.Item_ID";
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;


        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            //display all orders with item names
            string query = "select  O.Order_date, OI.*, it.item_name from Orders O JOIN Order_Items OI ON O.Order_ID = OI.Order_ID JOIN Items it ON it.Item_id = OI.Item_ID";
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            
            string query = "select O.Order_date, OI.Order_ID, count(OI.Item_ID) as 'Number of Items' from Orders O" +
                " JOIN Order_Items OI ON O.Order_ID = OI.Order_ID" +
                " group by OI.Order_ID, O.Order_date";
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            //calculate the value of each order
            //use the formula: sum of (item price * quantity)
            //use subquery to get the item price

            string query = "select O.Order_date, OI.Order_ID, sum(it.price * OI.Quantity) as 'Order Value' from Orders O" +
                " JOIN Order_Items OI ON O.Order_ID = OI.Order_ID" +
                " JOIN Items it ON it.Item_id = OI.Item_ID" +
                " group by OI.Order_ID, O.Order_date";
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            //use subquery to get the customer with highest number of orders also use group by
            string query = "select CONCAT(c.F_name,c.L_name) as 'Full Name', count(O.Order_ID) as 'Total_Orders' from Customer C" +
                " JOIN Orders O ON C.Customer_ID = O.Customer_ID" +
                " group by CONCAT(c.F_name,c.L_name)" +
                " having count(O.Order_ID)>5";

            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;

        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            //create view items_with_high_order as
            //select top 3 count(i.Item_name) as high_order from Items i join Order_Items o on i.Item_id = o.Item_id
            //group by i.Item_name
            //order by high_order desc

            string query = "select * from items_with_high_order";
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
        }
    }
}

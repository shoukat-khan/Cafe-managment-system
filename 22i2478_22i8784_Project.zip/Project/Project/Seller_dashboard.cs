﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Seller_dashboard : Form
    {
        string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        int seller_id;

        public Seller_dashboard(int seller_id)
        {
            InitializeComponent();
            this.seller_id = seller_id;
        }

        private void Seller_dashboard_Load(object sender, EventArgs e)
        {

            //display seller name
            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand("select * from Employee where Employee_ID = @seller_id", con);
            cmd.Parameters.AddWithValue("@seller_id", seller_id);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Seller_name.Text = dr["F_name"].ToString() + " " + dr["L_name"].ToString();
            }

            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //open the seller profile form
            Seller_Profile seller_Profile = new Seller_Profile(seller_id);
            seller_Profile.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
        
            //move to order reports form
            OrderReports orderReports = new OrderReports(seller_id);
            orderReports.Show();
            this.Hide();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //move to reservation reports form
            ReservationReports reservationReports = new ReservationReports(seller_id);
            reservationReports.Show();  
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //move to review reports form
            ReviewReports reviewReports = new ReviewReports(seller_id);
            reviewReports.Show();
            this.Hide();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Edit_admin_details_Form : Form
    {

        int id;

        public Edit_admin_details_Form(int id)
        {
           

            InitializeComponent();
            this.id = id;


            string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Administrator WHERE Administrator_ID = @Admin_ID", con);
                cmd.Parameters.AddWithValue("@Admin_ID", id);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    f_name_tbox.Text = reader["F_Name"].ToString();
                    L_name_tbox.Text = reader["L_Name"].ToString();

                    
                    pnum_tbox.Text = reader["PhoneNumber"].ToString();
                    email_tbox.Text = reader["Email"].ToString();

                }
            }

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Add_emp_btn_Click(object sender, EventArgs e)
        {
            if (f_name_tbox.Text == null || L_name_tbox.Text == null || pnum_tbox.Text == null || email_tbox.Text == null || (male_rbtn.Checked == false && female_rbtn.Checked == false))
            {
         

                MessageBox.Show("Please fill all fields");
              
            }
            else
            {
                //udate the record
                string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE Administrator SET F_name = @F_Name, L_name = @L_Name, PhoneNumber = @PhoneNumber, Email = @Email WHERE Account_ID = " + id, con);
                    cmd.Parameters.AddWithValue("@F_Name", f_name_tbox.Text);
                    cmd.Parameters.AddWithValue("@L_Name", L_name_tbox.Text);
                    cmd.Parameters.AddWithValue("@PhoneNumber", pnum_tbox.Text);
                    cmd.Parameters.AddWithValue("@Email", email_tbox.Text);
                    
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Records Updated");
            }
        }

        private void f_name_tbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            //move to Admin_Form
            Admin_Form admin_Form = new Admin_Form(id);
            admin_Form.Show();
            this.Hide();
        }

        private void pnum_tbox_TextChanged(object sender, EventArgs e)
        {

            if (pnum_tbox.Text.All(char.IsDigit) && pnum_tbox.Text.Length == 11)
            {
                pnum_tbox.BackColor = Color.LightGreen;
            }
            else
            {
                pnum_tbox.BackColor = Color.Red;
            }

            
        }

        private void Edit_admin_details_Form_Load(object sender, EventArgs e)
        {

        }
    }
}

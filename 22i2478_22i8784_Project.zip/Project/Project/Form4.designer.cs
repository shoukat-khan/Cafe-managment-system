﻿namespace database_project
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Seller_btn = new System.Windows.Forms.RadioButton();
            this.Customer_btn = new System.Windows.Forms.RadioButton();
            this.Admin_btn = new System.Windows.Forms.RadioButton();
            this.Login_register = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.login_btn = new System.Windows.Forms.Button();
            this.pass_login = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.login_user_name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.Seller_btn);
            this.panel1.Controls.Add(this.Customer_btn);
            this.panel1.Controls.Add(this.Admin_btn);
            this.panel1.Controls.Add(this.Login_register);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.login_btn);
            this.panel1.Controls.Add(this.pass_login);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.login_user_name);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(-2, -2);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(704, 422);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("HP Simplified", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(36, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(640, 83);
            this.label1.TabIndex = 1;
            this.label1.Text = "WELCOME BACK TO H.S CAFE MANAGMENT SYSTEM\r\n";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Seller_btn
            // 
            this.Seller_btn.AutoSize = true;
            this.Seller_btn.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seller_btn.Location = new System.Drawing.Point(537, 234);
            this.Seller_btn.Margin = new System.Windows.Forms.Padding(2);
            this.Seller_btn.Name = "Seller_btn";
            this.Seller_btn.Size = new System.Drawing.Size(77, 27);
            this.Seller_btn.TabIndex = 12;
            this.Seller_btn.TabStop = true;
            this.Seller_btn.Text = "Seller";
            this.Seller_btn.UseVisualStyleBackColor = true;
            this.Seller_btn.CheckedChanged += new System.EventHandler(this.Seller_btn_CheckedChanged);
            // 
            // Customer_btn
            // 
            this.Customer_btn.AutoSize = true;
            this.Customer_btn.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Customer_btn.Location = new System.Drawing.Point(410, 234);
            this.Customer_btn.Margin = new System.Windows.Forms.Padding(2);
            this.Customer_btn.Name = "Customer_btn";
            this.Customer_btn.Size = new System.Drawing.Size(106, 27);
            this.Customer_btn.TabIndex = 11;
            this.Customer_btn.TabStop = true;
            this.Customer_btn.Text = "Customer";
            this.Customer_btn.UseVisualStyleBackColor = true;
            this.Customer_btn.CheckedChanged += new System.EventHandler(this.Customer_btn_CheckedChanged);
            // 
            // Admin_btn
            // 
            this.Admin_btn.AutoSize = true;
            this.Admin_btn.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Admin_btn.Location = new System.Drawing.Point(311, 234);
            this.Admin_btn.Margin = new System.Windows.Forms.Padding(2);
            this.Admin_btn.Name = "Admin_btn";
            this.Admin_btn.Size = new System.Drawing.Size(79, 27);
            this.Admin_btn.TabIndex = 10;
            this.Admin_btn.TabStop = true;
            this.Admin_btn.Text = "Admin";
            this.Admin_btn.UseVisualStyleBackColor = true;
            this.Admin_btn.CheckedChanged += new System.EventHandler(this.Admin_btn_CheckedChanged);
            // 
            // Login_register
            // 
            this.Login_register.AutoSize = true;
            this.Login_register.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Login_register.Font = new System.Drawing.Font("HP Simplified", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login_register.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Login_register.Location = new System.Drawing.Point(456, 360);
            this.Login_register.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Login_register.Name = "Login_register";
            this.Login_register.Size = new System.Drawing.Size(146, 28);
            this.Login_register.TabIndex = 9;
            this.Login_register.Text = "Register Here";
            this.Login_register.Click += new System.EventHandler(this.Login_register_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("HP Simplified", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(201, 360);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(234, 28);
            this.label4.TabIndex = 8;
            this.label4.Text = "Don\'t have an account";
            // 
            // login_btn
            // 
            this.login_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.login_btn.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login_btn.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.login_btn.Location = new System.Drawing.Point(410, 289);
            this.login_btn.Margin = new System.Windows.Forms.Padding(2);
            this.login_btn.Name = "login_btn";
            this.login_btn.Size = new System.Drawing.Size(109, 43);
            this.login_btn.TabIndex = 6;
            this.login_btn.Text = "LOGIN!";
            this.login_btn.UseVisualStyleBackColor = true;
            this.login_btn.Click += new System.EventHandler(this.login_btn_Click);
            // 
            // pass_login
            // 
            this.pass_login.Font = new System.Drawing.Font("HP Simplified", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pass_login.Location = new System.Drawing.Point(307, 194);
            this.pass_login.Margin = new System.Windows.Forms.Padding(2);
            this.pass_login.Multiline = true;
            this.pass_login.Name = "pass_login";
            this.pass_login.PasswordChar = '*';
            this.pass_login.Size = new System.Drawing.Size(332, 30);
            this.pass_login.TabIndex = 5;
            this.pass_login.TextChanged += new System.EventHandler(this.pass_login_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label3.Location = new System.Drawing.Point(307, 172);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 23);
            this.label3.TabIndex = 4;
            this.label3.Text = "Password";
            // 
            // login_user_name
            // 
            this.login_user_name.Font = new System.Drawing.Font("HP Simplified", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login_user_name.Location = new System.Drawing.Point(307, 135);
            this.login_user_name.Margin = new System.Windows.Forms.Padding(2);
            this.login_user_name.Multiline = true;
            this.login_user_name.Name = "login_user_name";
            this.login_user_name.Size = new System.Drawing.Size(332, 30);
            this.login_user_name.TabIndex = 3;
            this.login_user_name.TextChanged += new System.EventHandler(this.login_user_name_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label2.Location = new System.Drawing.Point(307, 108);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "User_name";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(3, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(249, 370);
            this.panel2.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(254, 414);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 419);
            this.Controls.Add(this.panel1);
            this.HelpButton = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form4";
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label Login_register;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button login_btn;
        private System.Windows.Forms.TextBox pass_login;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox login_user_name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RadioButton Seller_btn;
        private System.Windows.Forms.RadioButton Customer_btn;
        private System.Windows.Forms.RadioButton Admin_btn;
    }
}
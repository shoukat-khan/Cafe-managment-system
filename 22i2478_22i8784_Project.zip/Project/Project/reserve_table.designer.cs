﻿namespace database_project
{
    partial class reserve_table
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(reserve_table));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Table_9 = new System.Windows.Forms.Panel();
            this.table9_status = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Table_8 = new System.Windows.Forms.Panel();
            this.table8_status = new System.Windows.Forms.TextBox();
            this.table7_status = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Table_7 = new System.Windows.Forms.Panel();
            this.Table_6 = new System.Windows.Forms.Panel();
            this.table6_status = new System.Windows.Forms.TextBox();
            this.Table_5 = new System.Windows.Forms.Panel();
            this.table5_status = new System.Windows.Forms.TextBox();
            this.Table_4 = new System.Windows.Forms.Panel();
            this.table4_status = new System.Windows.Forms.TextBox();
            this.Table_3 = new System.Windows.Forms.Panel();
            this.table3_status = new System.Windows.Forms.TextBox();
            this.Table_2 = new System.Windows.Forms.Panel();
            this.table2_status = new System.Windows.Forms.TextBox();
            this.Table_1 = new System.Windows.Forms.Panel();
            this.table1_status = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.Table_9.SuspendLayout();
            this.Table_8.SuspendLayout();
            this.Table_6.SuspendLayout();
            this.Table_5.SuspendLayout();
            this.Table_4.SuspendLayout();
            this.Table_3.SuspendLayout();
            this.Table_2.SuspendLayout();
            this.Table_1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(2, 1);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(598, 451);
            this.panel1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.Table_9);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.Table_8);
            this.panel3.Controls.Add(this.table7_status);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.Table_7);
            this.panel3.Controls.Add(this.Table_6);
            this.panel3.Controls.Add(this.Table_5);
            this.panel3.Controls.Add(this.Table_4);
            this.panel3.Controls.Add(this.Table_3);
            this.panel3.Controls.Add(this.Table_2);
            this.panel3.Controls.Add(this.Table_1);
            this.panel3.Location = new System.Drawing.Point(6, 6);
            this.panel3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(598, 451);
            this.panel3.TabIndex = 2;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label11.Font = new System.Drawing.Font("HP Simplified", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label11.Location = new System.Drawing.Point(227, -6);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(142, 37);
            this.label11.TabIndex = 74;
            this.label11.Text = "H.S CAFE ";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(535, -3);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(55, 37);
            this.label12.TabIndex = 73;
            this.label12.Text = "❎";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(-7, -6);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(46, 39);
            this.label13.TabIndex = 72;
            this.label13.Text = "⬅\r\n";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("HP Simplified", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(430, 425);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 16);
            this.label10.TabIndex = 21;
            this.label10.Text = "Tabel8";
            // 
            // Table_9
            // 
            this.Table_9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Table_9.BackgroundImage")));
            this.Table_9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Table_9.Controls.Add(this.table9_status);
            this.Table_9.Font = new System.Drawing.Font("HP Simplified", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table_9.Location = new System.Drawing.Point(385, 325);
            this.Table_9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Table_9.Name = "Table_9";
            this.Table_9.Size = new System.Drawing.Size(150, 98);
            this.Table_9.TabIndex = 20;
            this.Table_9.Paint += new System.Windows.Forms.PaintEventHandler(this.Table_9_Paint);
            // 
            // table9_status
            // 
            this.table9_status.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.table9_status.Location = new System.Drawing.Point(39, 0);
            this.table9_status.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.table9_status.Name = "table9_status";
            this.table9_status.Size = new System.Drawing.Size(76, 21);
            this.table9_status.TabIndex = 14;
            this.table9_status.Text = "NOT reserved";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("HP Simplified", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(272, 425);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 16);
            this.label9.TabIndex = 19;
            this.label9.Text = "Tabel8";
            // 
            // Table_8
            // 
            this.Table_8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Table_8.BackgroundImage")));
            this.Table_8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Table_8.Controls.Add(this.table8_status);
            this.Table_8.Font = new System.Drawing.Font("HP Simplified", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table_8.Location = new System.Drawing.Point(221, 325);
            this.Table_8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Table_8.Name = "Table_8";
            this.Table_8.Size = new System.Drawing.Size(148, 98);
            this.Table_8.TabIndex = 17;
            this.Table_8.Paint += new System.Windows.Forms.PaintEventHandler(this.Table_8_Paint);
            // 
            // table8_status
            // 
            this.table8_status.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.table8_status.Location = new System.Drawing.Point(39, 0);
            this.table8_status.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.table8_status.Name = "table8_status";
            this.table8_status.Size = new System.Drawing.Size(76, 21);
            this.table8_status.TabIndex = 14;
            this.table8_status.Text = "NOT reserved";
            // 
            // table7_status
            // 
            this.table7_status.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.table7_status.Font = new System.Drawing.Font("HP Simplified", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.table7_status.Location = new System.Drawing.Point(90, 325);
            this.table7_status.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.table7_status.Name = "table7_status";
            this.table7_status.Size = new System.Drawing.Size(76, 21);
            this.table7_status.TabIndex = 16;
            this.table7_status.Text = "NOT reserved";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("HP Simplified", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(108, 422);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 16);
            this.label7.TabIndex = 9;
            this.label7.Text = "Tabel7";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("HP Simplified", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(430, 289);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 16);
            this.label6.TabIndex = 8;
            this.label6.Text = "Tabel6";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("HP Simplified", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(272, 289);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "Tabel5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("HP Simplified", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(108, 289);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Tabel4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("HP Simplified", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(430, 148);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Tabel3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("HP Simplified", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(272, 148);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Tabel2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("HP Simplified", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(108, 148);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "Tabel1";
            // 
            // Table_7
            // 
            this.Table_7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Table_7.BackgroundImage")));
            this.Table_7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Table_7.Font = new System.Drawing.Font("HP Simplified", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table_7.Location = new System.Drawing.Point(53, 325);
            this.Table_7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Table_7.Name = "Table_7";
            this.Table_7.Size = new System.Drawing.Size(146, 94);
            this.Table_7.TabIndex = 2;
            this.Table_7.Paint += new System.Windows.Forms.PaintEventHandler(this.Table_7_Paint);
            // 
            // Table_6
            // 
            this.Table_6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Table_6.BackgroundImage")));
            this.Table_6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Table_6.Controls.Add(this.table6_status);
            this.Table_6.Font = new System.Drawing.Font("HP Simplified", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table_6.Location = new System.Drawing.Point(385, 182);
            this.Table_6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Table_6.Name = "Table_6";
            this.Table_6.Size = new System.Drawing.Size(150, 98);
            this.Table_6.TabIndex = 2;
            this.Table_6.Paint += new System.Windows.Forms.PaintEventHandler(this.Table_6_Paint);
            // 
            // table6_status
            // 
            this.table6_status.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.table6_status.Location = new System.Drawing.Point(38, 0);
            this.table6_status.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.table6_status.Name = "table6_status";
            this.table6_status.Size = new System.Drawing.Size(76, 21);
            this.table6_status.TabIndex = 15;
            this.table6_status.Text = "NOT reserved";
            // 
            // Table_5
            // 
            this.Table_5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Table_5.BackgroundImage")));
            this.Table_5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Table_5.Controls.Add(this.table5_status);
            this.Table_5.Font = new System.Drawing.Font("HP Simplified", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table_5.Location = new System.Drawing.Point(221, 182);
            this.Table_5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Table_5.Name = "Table_5";
            this.Table_5.Size = new System.Drawing.Size(148, 98);
            this.Table_5.TabIndex = 2;
            this.Table_5.Paint += new System.Windows.Forms.PaintEventHandler(this.Table_5_Paint);
            // 
            // table5_status
            // 
            this.table5_status.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.table5_status.Location = new System.Drawing.Point(39, 0);
            this.table5_status.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.table5_status.Name = "table5_status";
            this.table5_status.Size = new System.Drawing.Size(76, 21);
            this.table5_status.TabIndex = 14;
            this.table5_status.Text = "NOT reserved";
            // 
            // Table_4
            // 
            this.Table_4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Table_4.BackgroundImage")));
            this.Table_4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Table_4.Controls.Add(this.table4_status);
            this.Table_4.Font = new System.Drawing.Font("HP Simplified", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table_4.Location = new System.Drawing.Point(53, 182);
            this.Table_4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Table_4.Name = "Table_4";
            this.Table_4.Size = new System.Drawing.Size(146, 98);
            this.Table_4.TabIndex = 2;
            this.Table_4.Paint += new System.Windows.Forms.PaintEventHandler(this.Table_4_Paint);
            // 
            // table4_status
            // 
            this.table4_status.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.table4_status.Location = new System.Drawing.Point(37, 0);
            this.table4_status.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.table4_status.Name = "table4_status";
            this.table4_status.Size = new System.Drawing.Size(76, 21);
            this.table4_status.TabIndex = 13;
            this.table4_status.Text = "NOT reserved";
            // 
            // Table_3
            // 
            this.Table_3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Table_3.BackgroundImage")));
            this.Table_3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Table_3.Controls.Add(this.table3_status);
            this.Table_3.Font = new System.Drawing.Font("HP Simplified", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table_3.Location = new System.Drawing.Point(385, 37);
            this.Table_3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Table_3.Name = "Table_3";
            this.Table_3.Size = new System.Drawing.Size(150, 98);
            this.Table_3.TabIndex = 2;
            this.Table_3.Paint += new System.Windows.Forms.PaintEventHandler(this.Table_3_Paint);
            // 
            // table3_status
            // 
            this.table3_status.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.table3_status.Location = new System.Drawing.Point(38, 0);
            this.table3_status.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.table3_status.Name = "table3_status";
            this.table3_status.Size = new System.Drawing.Size(76, 21);
            this.table3_status.TabIndex = 12;
            this.table3_status.Text = "NOT reserved";
            // 
            // Table_2
            // 
            this.Table_2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Table_2.BackgroundImage")));
            this.Table_2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Table_2.Controls.Add(this.table2_status);
            this.Table_2.Font = new System.Drawing.Font("HP Simplified", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table_2.Location = new System.Drawing.Point(221, 40);
            this.Table_2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Table_2.Name = "Table_2";
            this.Table_2.Size = new System.Drawing.Size(148, 98);
            this.Table_2.TabIndex = 2;
            this.Table_2.Paint += new System.Windows.Forms.PaintEventHandler(this.Table_2_Paint);
            // 
            // table2_status
            // 
            this.table2_status.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.table2_status.Location = new System.Drawing.Point(39, -2);
            this.table2_status.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.table2_status.Name = "table2_status";
            this.table2_status.Size = new System.Drawing.Size(76, 21);
            this.table2_status.TabIndex = 11;
            this.table2_status.Text = "NOT reserved";
            // 
            // Table_1
            // 
            this.Table_1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Table_1.BackgroundImage")));
            this.Table_1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Table_1.Controls.Add(this.table1_status);
            this.Table_1.Font = new System.Drawing.Font("HP Simplified", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table_1.Location = new System.Drawing.Point(53, 40);
            this.Table_1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Table_1.Name = "Table_1";
            this.Table_1.Size = new System.Drawing.Size(146, 98);
            this.Table_1.TabIndex = 1;
            this.Table_1.Paint += new System.Windows.Forms.PaintEventHandler(this.Table_1_Paint);
            // 
            // table1_status
            // 
            this.table1_status.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.table1_status.Location = new System.Drawing.Point(37, -2);
            this.table1_status.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.table1_status.Name = "table1_status";
            this.table1_status.Size = new System.Drawing.Size(76, 21);
            this.table1_status.TabIndex = 10;
            this.table1_status.Text = "NOT reserved";
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(103, 37);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(123, 110);
            this.panel2.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(419, 382);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(156, 54);
            this.button1.TabIndex = 0;
            this.button1.Text = "RESERVE TABLE";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // reserve_table
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 449);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "reserve_table";
            this.Text = "reserve_table";
            this.Load += new System.EventHandler(this.reserve_table_Load);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.Table_9.ResumeLayout(false);
            this.Table_9.PerformLayout();
            this.Table_8.ResumeLayout(false);
            this.Table_8.PerformLayout();
            this.Table_6.ResumeLayout(false);
            this.Table_6.PerformLayout();
            this.Table_5.ResumeLayout(false);
            this.Table_5.PerformLayout();
            this.Table_4.ResumeLayout(false);
            this.Table_4.PerformLayout();
            this.Table_3.ResumeLayout(false);
            this.Table_3.PerformLayout();
            this.Table_2.ResumeLayout(false);
            this.Table_2.PerformLayout();
            this.Table_1.ResumeLayout(false);
            this.Table_1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel Table_1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel Table_7;
        private System.Windows.Forms.Panel Table_6;
        private System.Windows.Forms.Panel Table_5;
        private System.Windows.Forms.Panel Table_4;
        private System.Windows.Forms.Panel Table_3;
        private System.Windows.Forms.Panel Table_2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel Table_8;
        private System.Windows.Forms.TextBox table8_status;
        private System.Windows.Forms.TextBox table7_status;
        private System.Windows.Forms.TextBox table6_status;
        private System.Windows.Forms.TextBox table5_status;
        private System.Windows.Forms.TextBox table4_status;
        private System.Windows.Forms.TextBox table3_status;
        private System.Windows.Forms.TextBox table2_status;
        private System.Windows.Forms.TextBox table1_status;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel Table_9;
        private System.Windows.Forms.TextBox table9_status;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
    }
}
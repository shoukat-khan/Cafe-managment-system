﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ReservationReports : Form
    {
        int seller_id;
        string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;

        public ReservationReports(int seller_id)
        {
            InitializeComponent();
            this.seller_id = seller_id;
        }

        public ReservationReports()
        {
            InitializeComponent();
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            //move back to seller dashboard
            Seller_dashboard seller_Dashboard = new Seller_dashboard(seller_id);
            seller_Dashboard.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ReservationReports_Load(object sender, EventArgs e)
        {
           
            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand("select * from Table_Reservations", con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //show table reservations with customer names 
            con = new SqlConnection(connectionString);
            con.Open();
            string query = "select R.*, C.F_name, C.L_name from Table_Reservations R inner join Customer C on R.Customer_ID = C.Customer_ID";
            
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;


        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            
            con = new SqlConnection(connectionString);
            con.Open();
            string query = "select T.Table_num as 'Table Number', (select count(R.Table_num) from Table_Reservations R where R.Table_num = T.Table_num) as 'Total Reservations' from CafeTable T";
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            string query = "Select t.Table_num from CafeTable t where t.Table_num Not in (Select r.table_Num from Table_Reservations r)";
            con = new SqlConnection(connectionString);  
            con.Open();
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            string query = "Select c.customer_id, CONCAT(c.F_name,c.L_name) as 'Full Name', C.PhoneNumber from Customer C where C.customer_Id in (Select r.Customer_ID from Table_Reservations r)";

            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;

        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            //find table with maximum reservations
            string query = "select T.Table_num as 'Table Number', count(R.Table_num) as 'Total Reservations' from CafeTable T" +
                " inner join Table_Reservations R on T.Table_num = R.Table_num" +
                " group by T.Table_num" +
                " having count(R.Table_num)>2";
            
            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;


        }
    }
}

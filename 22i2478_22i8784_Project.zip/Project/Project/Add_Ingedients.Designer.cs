﻿namespace Project
{
    partial class Add_Ingedients
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Add_Ingedients));
            this.add_ing_btn = new System.Windows.Forms.Button();
            this.Quantity_tbox = new System.Windows.Forms.NumericUpDown();
            this.ItemID_tbox = new System.Windows.Forms.TextBox();
            this.ing_name_tbox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Back_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Quantity_tbox)).BeginInit();
            this.SuspendLayout();
            // 
            // add_ing_btn
            // 
            this.add_ing_btn.Font = new System.Drawing.Font("HP Simplified", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_ing_btn.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.add_ing_btn.Location = new System.Drawing.Point(318, 366);
            this.add_ing_btn.Name = "add_ing_btn";
            this.add_ing_btn.Size = new System.Drawing.Size(167, 35);
            this.add_ing_btn.TabIndex = 66;
            this.add_ing_btn.Text = "Add Ingredient";
            this.add_ing_btn.UseVisualStyleBackColor = true;
            this.add_ing_btn.Click += new System.EventHandler(this.add_ing_btn_Click);
            // 
            // Quantity_tbox
            // 
            this.Quantity_tbox.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Quantity_tbox.Location = new System.Drawing.Point(409, 264);
            this.Quantity_tbox.Name = "Quantity_tbox";
            this.Quantity_tbox.Size = new System.Drawing.Size(72, 30);
            this.Quantity_tbox.TabIndex = 65;
            // 
            // ItemID_tbox
            // 
            this.ItemID_tbox.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemID_tbox.Location = new System.Drawing.Point(409, 198);
            this.ItemID_tbox.Name = "ItemID_tbox";
            this.ItemID_tbox.Size = new System.Drawing.Size(100, 30);
            this.ItemID_tbox.TabIndex = 64;
            // 
            // ing_name_tbox
            // 
            this.ing_name_tbox.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ing_name_tbox.Location = new System.Drawing.Point(409, 137);
            this.ing_name_tbox.Name = "ing_name_tbox";
            this.ing_name_tbox.Size = new System.Drawing.Size(100, 30);
            this.ing_name_tbox.TabIndex = 63;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label6.Location = new System.Drawing.Point(276, 266);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 23);
            this.label6.TabIndex = 62;
            this.label6.Text = "Item Quantity";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label5.Location = new System.Drawing.Point(302, 201);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 23);
            this.label5.TabIndex = 61;
            this.label5.Text = "Item ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label4.Location = new System.Drawing.Point(254, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(140, 23);
            this.label4.TabIndex = 60;
            this.label4.Text = "Ingredient Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("HP Simplified", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(301, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(184, 41);
            this.label1.TabIndex = 67;
            this.label1.Text = "View Stock";
            // 
            // Back_btn
            // 
            this.Back_btn.Font = new System.Drawing.Font("HP Simplified Hans", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Back_btn.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Back_btn.Location = new System.Drawing.Point(24, 19);
            this.Back_btn.Name = "Back_btn";
            this.Back_btn.Size = new System.Drawing.Size(71, 32);
            this.Back_btn.TabIndex = 68;
            this.Back_btn.Text = "Back";
            this.Back_btn.UseVisualStyleBackColor = true;
            this.Back_btn.Click += new System.EventHandler(this.Back_btn_Click);
            // 
            // Add_Ingedients
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Back_btn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.add_ing_btn);
            this.Controls.Add(this.Quantity_tbox);
            this.Controls.Add(this.ItemID_tbox);
            this.Controls.Add(this.ing_name_tbox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Name = "Add_Ingedients";
            this.Text = "Add_Ingedients";
            ((System.ComponentModel.ISupportInitialize)(this.Quantity_tbox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button add_ing_btn;
        private System.Windows.Forms.NumericUpDown Quantity_tbox;
        private System.Windows.Forms.TextBox ItemID_tbox;
        private System.Windows.Forms.TextBox ing_name_tbox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Back_btn;
    }
}
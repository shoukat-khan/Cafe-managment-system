﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Seller_Profile : Form
    {
        int sellerId;
        string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;

        public Seller_Profile(int sellerid)
        {
            InitializeComponent();
            this.sellerId = sellerid;
        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void Seller_Profile_Load(object sender, EventArgs e)
        {

            //fill the seller profile
            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand("select * from Employee where Employee_ID = @seller_id", con);
            cmd.Parameters.AddWithValue("@seller_id", sellerId);
            
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                f_namelbl.Text = dr["F_name"].ToString();
                l_name_lbl.Text = dr["L_name"].ToString();
                gender_lbl.Text = dr["Gender"].ToString();
                email_lbl.Text = dr["Email"].ToString();
                p_num_lbl.Text = dr["PhoneNumber"].ToString();
                salary_lbl.Text = dr["Salary"].ToString();
                
                
            }

           int account_id = 0;
            try { 
            //get the account id of the seller
            cmd = new SqlCommand("select Account_ID from Employee where Employee_ID = @seller_id", con);
            cmd.Parameters.AddWithValue("@seller_id", sellerId);
            dr.Close();
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                account_id = Convert.ToInt32(dr["Account_ID"]);
            }

            //get the account details of the seller
            cmd = new SqlCommand("select * from User_Account where Account_ID = @account_id", con);
            cmd.Parameters.AddWithValue("@account_id", account_id);
            dr.Close();
                dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                uname_lbl.Text = dr["UserName"].ToString();
                pass_lbl.Text = dr["UserPassword"].ToString();
            }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            //move to seller dashboard
            Seller_dashboard seller_Dashboard = new Seller_dashboard(sellerId);
            seller_Dashboard.Show();
            this.Hide();
        }

        private void edit_details_btn_Click(object sender, EventArgs e)
        {
            //move to edit employee details form
            EditEmpDetails editEmpDetails = new EditEmpDetails(sellerId);
            editEmpDetails.Show();
            this.Hide();
        }
    }
}

﻿namespace Project
{
    partial class Add_Items_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Add_Items_Form));
            this.label1 = new System.Windows.Forms.Label();
            this.Back_btn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tea_rbtn = new System.Windows.Forms.RadioButton();
            this.Coffee_rbtn = new System.Windows.Forms.RadioButton();
            this.Cake_rbtn = new System.Windows.Forms.RadioButton();
            this.shake_rbtn = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.item_name_tbox = new System.Windows.Forms.TextBox();
            this.Price_tbox = new System.Windows.Forms.TextBox();
            this.Quantity_tbox = new System.Windows.Forms.NumericUpDown();
            this.add_item_btn = new System.Windows.Forms.Button();
            this.Add_ing_btn = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Quantity_tbox)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("HP Simplified", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(323, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 41);
            this.label1.TabIndex = 48;
            this.label1.Text = "Add Items";
            // 
            // Back_btn
            // 
            this.Back_btn.Font = new System.Drawing.Font("HP Simplified Hans", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Back_btn.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Back_btn.Location = new System.Drawing.Point(22, 19);
            this.Back_btn.Name = "Back_btn";
            this.Back_btn.Size = new System.Drawing.Size(71, 32);
            this.Back_btn.TabIndex = 49;
            this.Back_btn.Text = "Back";
            this.Back_btn.UseVisualStyleBackColor = true;
            this.Back_btn.Click += new System.EventHandler(this.Back_btn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Impact", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label2.Location = new System.Drawing.Point(216, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(414, 26);
            this.label2.TabIndex = 50;
            this.label2.Text = "Add the information below to add new products";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label3.Location = new System.Drawing.Point(19, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 23);
            this.label3.TabIndex = 51;
            this.label3.Text = "Select the category";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.shake_rbtn);
            this.groupBox1.Controls.Add(this.Cake_rbtn);
            this.groupBox1.Controls.Add(this.Coffee_rbtn);
            this.groupBox1.Controls.Add(this.tea_rbtn);
            this.groupBox1.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(22, 189);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(207, 135);
            this.groupBox1.TabIndex = 52;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Categories";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // tea_rbtn
            // 
            this.tea_rbtn.AutoSize = true;
            this.tea_rbtn.Location = new System.Drawing.Point(7, 24);
            this.tea_rbtn.Name = "tea_rbtn";
            this.tea_rbtn.Size = new System.Drawing.Size(54, 27);
            this.tea_rbtn.TabIndex = 0;
            this.tea_rbtn.Text = "Tea";
            this.tea_rbtn.UseVisualStyleBackColor = true;
            this.tea_rbtn.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // Coffee_rbtn
            // 
            this.Coffee_rbtn.AutoSize = true;
            this.Coffee_rbtn.Location = new System.Drawing.Point(7, 48);
            this.Coffee_rbtn.Name = "Coffee_rbtn";
            this.Coffee_rbtn.Size = new System.Drawing.Size(78, 27);
            this.Coffee_rbtn.TabIndex = 1;
            this.Coffee_rbtn.TabStop = true;
            this.Coffee_rbtn.Text = "Coffee";
            this.Coffee_rbtn.UseVisualStyleBackColor = true;
            // 
            // Cake_rbtn
            // 
            this.Cake_rbtn.AutoSize = true;
            this.Cake_rbtn.Location = new System.Drawing.Point(7, 72);
            this.Cake_rbtn.Name = "Cake_rbtn";
            this.Cake_rbtn.Size = new System.Drawing.Size(72, 27);
            this.Cake_rbtn.TabIndex = 2;
            this.Cake_rbtn.TabStop = true;
            this.Cake_rbtn.Text = "Cakes";
            this.Cake_rbtn.UseVisualStyleBackColor = true;
            // 
            // shake_rbtn
            // 
            this.shake_rbtn.AutoSize = true;
            this.shake_rbtn.Location = new System.Drawing.Point(7, 96);
            this.shake_rbtn.Name = "shake_rbtn";
            this.shake_rbtn.Size = new System.Drawing.Size(82, 27);
            this.shake_rbtn.TabIndex = 3;
            this.shake_rbtn.TabStop = true;
            this.shake_rbtn.Text = "Shakes";
            this.shake_rbtn.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label4.Location = new System.Drawing.Point(248, 152);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 23);
            this.label4.TabIndex = 53;
            this.label4.Text = "Item Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label5.Location = new System.Drawing.Point(248, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 23);
            this.label5.TabIndex = 54;
            this.label5.Text = "Item Price";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label6.Location = new System.Drawing.Point(248, 274);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 23);
            this.label6.TabIndex = 55;
            this.label6.Text = "Item Quantity";
            // 
            // item_name_tbox
            // 
            this.item_name_tbox.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item_name_tbox.Location = new System.Drawing.Point(365, 149);
            this.item_name_tbox.Name = "item_name_tbox";
            this.item_name_tbox.Size = new System.Drawing.Size(100, 30);
            this.item_name_tbox.TabIndex = 56;
            // 
            // Price_tbox
            // 
            this.Price_tbox.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Price_tbox.Location = new System.Drawing.Point(365, 210);
            this.Price_tbox.Name = "Price_tbox";
            this.Price_tbox.Size = new System.Drawing.Size(100, 30);
            this.Price_tbox.TabIndex = 57;
            // 
            // Quantity_tbox
            // 
            this.Quantity_tbox.Font = new System.Drawing.Font("HP Simplified", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Quantity_tbox.Location = new System.Drawing.Point(393, 271);
            this.Quantity_tbox.Name = "Quantity_tbox";
            this.Quantity_tbox.Size = new System.Drawing.Size(72, 30);
            this.Quantity_tbox.TabIndex = 58;
            this.Quantity_tbox.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // add_item_btn
            // 
            this.add_item_btn.Font = new System.Drawing.Font("HP Simplified", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_item_btn.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.add_item_btn.Location = new System.Drawing.Point(365, 390);
            this.add_item_btn.Name = "add_item_btn";
            this.add_item_btn.Size = new System.Drawing.Size(115, 35);
            this.add_item_btn.TabIndex = 59;
            this.add_item_btn.Text = "Add Item";
            this.add_item_btn.UseVisualStyleBackColor = true;
            this.add_item_btn.Click += new System.EventHandler(this.add_item_btn_Click);
            // 
            // Add_ing_btn
            // 
            this.Add_ing_btn.Font = new System.Drawing.Font("HP Simplified", 15.75F, System.Drawing.FontStyle.Bold);
            this.Add_ing_btn.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Add_ing_btn.Location = new System.Drawing.Point(560, 213);
            this.Add_ing_btn.Name = "Add_ing_btn";
            this.Add_ing_btn.Size = new System.Drawing.Size(160, 36);
            this.Add_ing_btn.TabIndex = 60;
            this.Add_ing_btn.Text = "Add Ingredients";
            this.Add_ing_btn.UseVisualStyleBackColor = true;
            this.Add_ing_btn.Click += new System.EventHandler(this.Add_ing_btn_Click);
            // 
            // Add_Items_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Add_ing_btn);
            this.Controls.Add(this.add_item_btn);
            this.Controls.Add(this.Quantity_tbox);
            this.Controls.Add(this.Price_tbox);
            this.Controls.Add(this.item_name_tbox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Back_btn);
            this.Controls.Add(this.label1);
            this.Name = "Add_Items_Form";
            this.Text = "Add_Items_Form";
            this.Load += new System.EventHandler(this.Add_Items_Form_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Quantity_tbox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Back_btn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton tea_rbtn;
        private System.Windows.Forms.RadioButton Cake_rbtn;
        private System.Windows.Forms.RadioButton Coffee_rbtn;
        private System.Windows.Forms.RadioButton shake_rbtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox item_name_tbox;
        private System.Windows.Forms.TextBox Price_tbox;
        private System.Windows.Forms.NumericUpDown Quantity_tbox;
        private System.Windows.Forms.Button add_item_btn;
        private System.Windows.Forms.Button Add_ing_btn;
    }
}
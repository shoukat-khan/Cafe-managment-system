﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class viewstock2 : Form
    {
        public viewstock2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //move to Admin_Form
            Admin_Form admin_Form = new Admin_Form();
            admin_Form.Show();
            this.Hide();
        }

        private void viewstock2_Load(object sender, EventArgs e)
        {
            //show the items with more than 10 ingredients
            string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
             
                SqlCommand cmd = new SqlCommand("Select I.Item_id, I.item_name from Item_Ingredients n Join Items I ON n.Item_ID=I.Item_id Group by I.Item_id, I.item_name having count(n.Ingredient_ID)>5", con);

                //add headers to the table
                tableLayoutPanel1.Controls.Add(new Label() { Text = "Item ID" });
                tableLayoutPanel1.Controls.Add(new Label() { Text = "Item Name" });


                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    //add items to the table
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["Item_ID"].ToString() });
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["Item_Name"].ToString() });
                }

            }

        }
    }
}

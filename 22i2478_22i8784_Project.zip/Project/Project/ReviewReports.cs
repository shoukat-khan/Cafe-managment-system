﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ReviewReports : Form
    {

        string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        int sellerId;

        public ReviewReports(int sellerid)
        {
            InitializeComponent();
            this.sellerId = sellerid;
        }

        public ReviewReports()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //View
            //create view review_less_than_3 as
            //select i.item_name from Items i join Reviews r on r.Item_ID = i.Item_id
            //where r.Rating < 3
            //select* from review_less_than_3

            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand("select * from review_less_than_3", con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;



        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            //move back to seller dashboard
            Seller_dashboard seller_Dashboard = new Seller_dashboard(sellerId);
            seller_Dashboard.Show();
            this.Hide();
        }

        private void ReviewReports_Load(object sender, EventArgs e)
        {
            //create view report as
            //select c.F_name,c.L_name
            //from Customer c
            //join Reviews r on r.Customer_ID = c.Customer_ID
            //join Items i on i.Item_id = r.Item_ID
            //join Categories ca on ca.Category_id = i.Category_id
            //group by ca.Category_name, c.F_name,c.L_name;

            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand("select * from report", con);
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

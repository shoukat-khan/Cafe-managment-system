﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Xml.Linq;

namespace database_project
{


    public partial class Form3 : Form
    {



        public Form3()
        {
            InitializeComponent();
        }

        private void signup_email_TextChanged(object sender, EventArgs e)
        {

        }

        private void signup_username_TextChanged(object sender, EventArgs e)
        {

        }

        private void PASS_TEXT_TextChanged(object sender, EventArgs e)
        {

        }

        private void signup_show_pass_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void Last_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void Phone_no_TextChanged(object sender, EventArgs e)
        {

        }

        private void Gender_TextChanged(object sender, EventArgs e)
        {

        }

        private void FIrst_name_TextChanged(object sender, EventArgs e)
        {

        }




        private void signup_btn_Click(object sender, EventArgs e)
        {
            string email = signup_email.Text;
            string username = signup_username.Text;
            string pass = PASS_TEXT.Text;
            string role = "Customer";
            string fname = FIrst_name.Text;
            string lname = Last_name.Text;
            string gender = Gender.Text;
            string phoneNumber = Phone_no.Text;

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(username) || string.IsNullOrEmpty(pass) ||
                string.IsNullOrEmpty(fname) || string.IsNullOrEmpty(lname) || string.IsNullOrEmpty(gender) || string.IsNullOrEmpty(phoneNumber))
            {
                MessageBox.Show("Please fill all the fields");
            }
            else
            {
                try
                {
                    string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";

                    using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        con.Open();
                        string userAccountQuery = "INSERT INTO User_Account (UserName, UserPassword) VALUES (@UserName, @UserPassword) SELECT SCOPE_IDENTITY();";
                        SqlCommand userAccountCmd = new SqlCommand(userAccountQuery, con);
                        userAccountCmd.Parameters.AddWithValue("@UserName", username);
                        userAccountCmd.Parameters.AddWithValue("@UserPassword", pass);
                        int accountId = Convert.ToInt32(userAccountCmd.ExecuteScalar());



                        string customerQuery = "INSERT INTO Customer (Account_ID, F_name, L_name, Gender, PhoneNumber, Email) VALUES (@AccountId, @F_Name, @L_Name, @Gender, @PhoneNumber, @Email)";
                        SqlCommand customerCmd = new SqlCommand(customerQuery, con);
                        customerCmd.Parameters.AddWithValue("@AccountId", accountId);
                        customerCmd.Parameters.AddWithValue("@F_Name", fname);
                        customerCmd.Parameters.AddWithValue("@L_Name", lname);
                        customerCmd.Parameters.AddWithValue("@Gender", gender);
                        customerCmd.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                        customerCmd.Parameters.AddWithValue("@Email", email);
                        customerCmd.ExecuteNonQuery();
                    }
                    MessageBox.Show("User registered successfully now please login to enter into the app ");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

            private void signup_to_login_here_Click(object sender, EventArgs e)
        {
            Form4 s = new Form4();
            s.Show();
            this.Hide();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Gen_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}

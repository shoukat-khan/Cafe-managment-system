﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ViewStock : Form
    {
        public ViewStock()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            //get items data from database and then display it in the table



        }

        private void ViewStock_Load(object sender, EventArgs e)
        {
            //add headers to the table
            tableLayoutPanel1.Controls.Add(new Label() { Text = "Item ID" });
            tableLayoutPanel1.Controls.Add(new Label() { Text = "Item Name" });
            tableLayoutPanel1.Controls.Add(new Label() { Text = "Price" });
            tableLayoutPanel1.Controls.Add(new Label() { Text = "Quantity" });
            tableLayoutPanel1.Controls.Add(new Label() { Text = "Category" });

            string connectionString = "Data Source=DESKTOP-R02MLBI\\SQLEXPRESS;Initial Catalog=db_project;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Items", con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    //add items to the table
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["Item_ID"].ToString() });
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["Item_Name"].ToString() });
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["Price"].ToString() });
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["Quantity"].ToString() });
                    tableLayoutPanel1.Controls.Add(new Label() { Text = reader["Category_ID"].ToString() });
                
                }
            }

        }

        private void tableLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //move to admin form
            Admin_Form admin_Form = new Admin_Form();
            admin_Form.Show();
            this.Hide();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //move to view stock3 form
            Form form = new Viewstock3();
            form.Show();
            this.Hide();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //move to view stock2 form
            Form form = new viewstock2();
            form.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //move to view stock4 form
            Stock4 form = new Stock4();
            form.Show();
            this.Hide();

        }
    }
}
